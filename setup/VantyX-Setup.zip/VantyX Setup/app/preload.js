// Brücke zwischen VantyX-Oberfläche und App – nur diese Funktionen sind erreichbar
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("vantyx", {
  isApp: true,
  platform: process.platform,
  tv: {
    show: (rect, url) => ipcRenderer.send("tv:show", { rect, url }),
    bounds: rect => ipcRenderer.send("tv:bounds", rect),
    hide: () => ipcRenderer.send("tv:hide"),
    cmd: (cmd, arg) => ipcRenderer.send("tv:cmd", { cmd, arg }),
    onState: fn => ipcRenderer.on("tv:state", (_e, s) => fn(s)),
  },
  focus: () => ipcRenderer.send("win:focus"),
  ready: () => ipcRenderer.send("app:ready"),
  update: {
    get: () => ipcRenderer.invoke("upd:get"),
    check: () => ipcRenderer.invoke("upd:check"),
    install: () => ipcRenderer.send("upd:install"),
    onState: fn => ipcRenderer.on("upd:state", (_e, s) => fn(s)),
  },
});
