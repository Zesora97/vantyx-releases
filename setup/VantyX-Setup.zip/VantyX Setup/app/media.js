// VantyX – "Läuft gerade": liest die Windows-Mediensteuerung (Spotify, YouTube, …) und steuert Play/Pause/Weiter.
// Ein einziger, unsichtbarer PowerShell-Prozess läuft im Hintergrund, solange das Musik-Widget sichtbar ist.
"use strict";
const { spawn } = require("node:child_process");

const PS = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' } | Select-Object -First 1
function Await($op, [Type]$t) { $task = $m.MakeGenericMethod($t).Invoke($null, @($op)); [void]$task.Wait(4000); return $task.Result }
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
if (-not $mgr) { [Console]::Out.WriteLine('{"ok":false,"err":"nomgr"}'); [Console]::Out.Flush(); exit }
$last = ''; $lastArtKey = ''; $art = ''
$read = [Console]::In.ReadLineAsync()
while ($true) {
  if ($read.IsCompleted) {
    $cmd = $read.Result; if ($null -eq $cmd -or $cmd -eq 'quit') { exit }
    $s = $mgr.GetCurrentSession()
    if ($s) {
      if ($cmd -eq 'toggle') { [void](Await ($s.TryTogglePlayPauseAsync()) ([bool])) }
      elseif ($cmd -eq 'next') { [void](Await ($s.TrySkipNextAsync()) ([bool])) }
      elseif ($cmd -eq 'prev') { [void](Await ($s.TrySkipPreviousAsync()) ([bool])) }
    }
    $read = [Console]::In.ReadLineAsync(); $last = ''
  }
  $o = @{ ok = $true; has = $false }
  $s = $mgr.GetCurrentSession()
  if ($s) {
    $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
    $pb = $s.GetPlaybackInfo()
    $o.has = $true; $o.app = [string]$s.SourceAppUserModelId
    $o.title = [string]$p.Title; $o.artist = [string]$p.Artist; $o.album = [string]$p.AlbumTitle
    $o.status = [string]$pb.PlaybackStatus
    $key = $o.app + '|' + $o.title + '|' + $o.artist
    if ($key -ne $lastArtKey) {
      $lastArtKey = $key; $art = ''
      if ($p.Thumbnail) {
        $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
        if ($st -and $st.Size -gt 0 -and $st.Size -lt 2000000) {
          $rd = New-Object Windows.Storage.Streams.DataReader($st.GetInputStreamAt(0))
          [void](Await ($rd.LoadAsync([uint32]$st.Size)) ([uint32]))
          $b = New-Object byte[] ([int]$st.Size); $rd.ReadBytes($b)
          $art = 'data:' + $st.ContentType + ';base64,' + [Convert]::ToBase64String($b)
        }
      }
    }
    $o.art = $art
  }
  $j = $o | ConvertTo-Json -Compress
  if ($j -ne $last) { $last = $j; [Console]::Out.WriteLine($j); [Console]::Out.Flush() }
  Start-Sleep -Milliseconds 900
}
`;

function create({ log, onState }) {
  let ps = null, buf = "", subs = 0, stopT = null, state = { ok: process.platform === "win32", has: false, unsupported: process.platform !== "win32" };
  const emit = s => { state = s; try { onState(s); } catch {} };

  function start() {
    if (ps || process.platform !== "win32") return;
    try {
      const enc = Buffer.from(PS, "utf16le").toString("base64");
      ps = spawn("powershell.exe", ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc], { windowsHide: true, stdio: ["pipe", "pipe", "pipe"] });
    } catch (e) { log(`Musik-Widget: PowerShell nicht startbar – ${e.message}`); ps = null; return; }
    ps.stdout.setEncoding("utf8");
    ps.stdout.on("data", d => {
      buf += d; let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith("{")) continue;
        try { const j = JSON.parse(line); emit({ ok: j.ok !== false, has: !!j.has, app: j.app || "", title: j.title || "", artist: j.artist || "", album: j.album || "", status: j.status || "", art: j.art || "" }); } catch {}
      }
    });
    ps.stderr.on("data", () => {});
    ps.on("exit", () => { ps = null; buf = ""; });
  }
  function stop() { if (!ps) return; try { ps.stdin.write("quit\n"); } catch {} const p = ps; setTimeout(() => { try { p.kill(); } catch {} }, 1500); ps = null; }

  return {
    subscribe() { subs++; clearTimeout(stopT); start(); return state; },
    unsubscribe() { subs = Math.max(0, subs - 1); if (!subs) { clearTimeout(stopT); stopT = setTimeout(stop, 30000); } },
    cmd(c) { if (ps && ["toggle", "next", "prev"].includes(c)) { try { ps.stdin.write(c + "\n"); } catch {} } },
    get: () => state,
    stop,
  };
}

module.exports = { create, PS };
