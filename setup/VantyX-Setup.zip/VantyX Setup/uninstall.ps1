﻿#  VantyX – Deinstallation
Add-Type -AssemblyName System.Windows.Forms
$Dest = Join-Path $env:LOCALAPPDATA 'Programs\VantyX'
$Data = Join-Path $env:APPDATA 'VantyX'

$r = [System.Windows.Forms.MessageBox]::Show('VantyX wirklich deinstallieren?', 'VantyX', 'YesNo', 'Question')
if ($r -ne 'Yes') { exit }

Get-Process -Name 'VantyX' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*vantyx.pyw*' -or $_.CommandLine -like '*VantyX*app-profil*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800

foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    Remove-Item -Path (Join-Path $dir 'VantyX.lnk') -Force -ErrorAction SilentlyContinue
}
Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\VantyX' -Recurse -Force -ErrorAction SilentlyContinue

$d = [System.Windows.Forms.MessageBox]::Show("Sollen auch deine Daten gelöscht werden?`r`n(Einstellungen, API-Schlüssel, Trades und TradingView-Anmeldung)", 'VantyX', 'YesNo', 'Question')
if ($d -eq 'Yes') { Remove-Item -Path $Data -Recurse -Force -ErrorAction SilentlyContinue }

# Programmordner nach dem Beenden dieses Skripts entfernen
Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c timeout /t 2 >nul & rmdir /s /q "' + $Dest + '"') -WindowStyle Hidden
[System.Windows.Forms.MessageBox]::Show('VantyX wurde deinstalliert.', 'VantyX', 'OK', 'Information') | Out-Null
