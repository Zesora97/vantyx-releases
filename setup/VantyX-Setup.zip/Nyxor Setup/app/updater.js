// VantyX – automatische Updates über GitHub-Releases
// Ablauf: neueste Release abfragen → Update-Paket laden → jede Datei per SHA-256 prüfen →
// in DATA/update/staged ablegen → beim Klick auf „Neu starten“ (oder spätestens beim nächsten Start) einspielen.
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const REPO = "Zesora97/vantyx-releases";
// latest.json im Repo: {version, label, notes, update: <URL Update-Paket>, setup: <URL Setup-Zip>}
const API = process.env.TC_UPDATE_URL || `https://raw.githubusercontent.com/${REPO}/main/latest.json`;
const OK_URL = /^https:\/\/(github\.com|raw\.githubusercontent\.com|objects\.githubusercontent\.com)\//;
const ASSET = "vantyx-update.json";
const OK_PATH = /^(ui\/)?[A-Za-z0-9][A-Za-z0-9._-]{0,60}\.(js|json|html|css|png|jpg|webp|ico|svg|webmanifest)$/;

const sha = buf => crypto.createHash("sha256").update(buf).digest("hex");

function cmp(a, b) {   // "2.4.0" vs "2.3.1" → 1 / 0 / -1
  const pa = String(a).replace(/^v/i, "").split(/[.-]/).map(n => parseInt(n, 10) || 0);
  const pb = String(b).replace(/^v/i, "").split(/[.-]/).map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}

// Paket prüfen: nur erlaubte Dateien, Prüfsummen müssen stimmen
function verify(pkg, electronVersion) {
  if (!pkg || pkg.app !== "vantyx" || !pkg.version || !pkg.files || typeof pkg.files !== "object") throw new Error("Update-Paket ist ungültig");
  const out = {};
  for (const [rel, f] of Object.entries(pkg.files)) {
    if (!OK_PATH.test(rel) || rel.includes("..")) throw new Error(`Unerlaubte Datei im Update: ${rel}`);
    const buf = Buffer.from(String(f.data || ""), "base64");
    if (sha(buf) !== String(f.sha256 || "").toLowerCase()) throw new Error(`Prüfsumme stimmt nicht: ${rel}`);
    out[rel] = buf;
  }
  if (!out["main.js"] || !out["package.json"] || !out["ui/vantyx.html"]) throw new Error("Update-Paket ist unvollständig");
  const needsSetup = !!(pkg.electron && electronVersion && pkg.electron !== electronVersion);
  return { files: out, needsSetup };
}

function create({ root, dataDir, currentVersion, electronVersion, fetch, log, onState }) {
  const dir = path.join(dataDir, "update"), staged = path.join(dir, "staged");
  let state = { state: "idle", current: currentVersion }, busy = null;
  const set = s => { state = { current: currentVersion, ...s }; try { onState(state); } catch {} };

  async function getJson(u) {
    const r = await fetch(u, { headers: { "Accept": "application/vnd.github+json", "User-Agent": "VantyX-Updater" }, cache: "no-store" });
    if (!r.ok) throw new Error(`GitHub antwortet mit ${r.status}`);
    return r.json();
  }

  async function check(manual) {
    if (busy) return busy;
    busy = (async () => {
      if (state.state === "ready") return state;
      set({ state: "checking", manual: !!manual });
      try {
        const rel = await getJson(API + (API.includes("?") ? "&" : "?") + "t=" + Date.now());
        const ver = String(rel.version || rel.tag_name || "").replace(/^v/i, "");
        const notes = String(rel.notes || rel.body || "").slice(0, 4000), page = OK_URL.test(rel.setup || "") ? rel.setup : (rel.html_url || `https://github.com/${REPO}`);
        if (!ver || cmp(ver, currentVersion) <= 0) { set({ state: "none", latest: ver || currentVersion, manual: !!manual }); return state; }
        const asset = rel.update ? { browser_download_url: rel.update } : (rel.assets || []).find(a => a.name === ASSET);
        if (!asset || (!process.env.TC_UPDATE_URL && !OK_URL.test(asset.browser_download_url))) { set({ state: "setup", version: ver, notes, url: page }); return state; }
        set({ state: "downloading", version: ver, notes });
        const r = await fetch(asset.browser_download_url, { headers: { "Accept": "application/octet-stream", "User-Agent": "VantyX-Updater" } });
        if (!r.ok) throw new Error(`Download fehlgeschlagen (${r.status})`);
        const pkg = JSON.parse(Buffer.from(await r.arrayBuffer()).toString("utf8"));
        if (cmp(pkg.version, ver) !== 0) throw new Error("Versionsnummer im Paket passt nicht zur Release");
        const { files, needsSetup } = verify(pkg, electronVersion);
        if (needsSetup) { set({ state: "setup", version: ver, notes, url: page }); return state; }
        fs.rmSync(staged, { recursive: true, force: true });
        for (const [rel2, buf] of Object.entries(files)) { const f = path.join(staged, rel2); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, buf); }
        fs.writeFileSync(path.join(staged, "update.json"), JSON.stringify({ version: ver, label: pkg.label || ver, notes: String(pkg.notes || notes || "").slice(0, 4000), files: Object.fromEntries(Object.entries(files).map(([k, b]) => [k, sha(b)])) }));
        log(`Update ${ver} geladen und geprüft – wird beim Neustart eingespielt`);
        set({ state: "ready", version: ver, label: pkg.label || ver, notes });
      } catch (e) {
        log(`Update-Prüfung fehlgeschlagen: ${e.message}`);
        set({ state: "error", message: e.message, manual: !!manual });
      }
      return state;
    })().finally(() => { busy = null; });
    return busy;
  }

  let timer = null;
  function schedule(firstDelay, every) {
    setTimeout(() => check(false), firstDelay);
    timer = setInterval(() => check(false), every);
    if (timer.unref) timer.unref();
  }

  return { check, schedule, get: () => state };
}

// Beim Start: liegt ein geprüftes Update bereit, wird es eingespielt (vor dem Laden der restlichen App)
function applyStaged({ root, dataDir, currentVersion, log }) {
  const dir = path.join(dataDir, "update"), staged = path.join(dir, "staged"), mf = path.join(staged, "update.json");
  if (!fs.existsSync(mf)) return false;
  let info;
  try { info = JSON.parse(fs.readFileSync(mf, "utf8")); } catch { fs.rmSync(staged, { recursive: true, force: true }); return false; }
  if (!info || cmp(info.version, currentVersion) <= 0) { fs.rmSync(staged, { recursive: true, force: true }); return false; }
  const rels = Object.keys(info.files || {});
  // erst alles erneut prüfen, dann sichern, dann ersetzen
  for (const rel of rels) {
    if (!OK_PATH.test(rel)) { fs.rmSync(staged, { recursive: true, force: true }); return false; }
    const f = path.join(staged, rel);
    if (!fs.existsSync(f) || sha(fs.readFileSync(f)) !== info.files[rel]) { log("Update verworfen: Dateien beschädigt"); fs.rmSync(staged, { recursive: true, force: true }); return false; }
  }
  const backup = path.join(dir, "vorher-" + currentVersion);
  try {
    fs.rmSync(backup, { recursive: true, force: true });
    for (const rel of rels) {
      const cur = path.join(root, rel);
      if (fs.existsSync(cur)) { fs.mkdirSync(path.dirname(path.join(backup, rel)), { recursive: true }); fs.copyFileSync(cur, path.join(backup, rel)); }
    }
    for (const rel of rels) {
      const dst = path.join(root, rel), tmp = dst + ".neu";
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      fs.copyFileSync(path.join(staged, rel), tmp);
      fs.renameSync(tmp, dst);
    }
  } catch (e) {
    log(`Update konnte nicht eingespielt werden: ${e.message} – stelle alte Version wieder her`);
    for (const rel of rels) { try { const b = path.join(backup, rel); if (fs.existsSync(b)) fs.copyFileSync(b, path.join(root, rel)); } catch {} }
    try { fs.writeFileSync(path.join(dir, "fehler.txt"), e.message); } catch {}
    fs.rmSync(staged, { recursive: true, force: true });
    return false;
  }
  fs.rmSync(staged, { recursive: true, force: true });
  try { fs.writeFileSync(path.join(dir, "neu.json"), JSON.stringify({ from: currentVersion, to: info.version, label: info.label, notes: info.notes || "", at: Date.now() })); } catch {}
  log(`Update ${currentVersion} → ${info.version} eingespielt`);
  return true;
}

// Nach einem Update einmal „Neu in Version …“ anzeigen
function takeJustUpdated(dataDir) {
  const f = path.join(dataDir, "update", "neu.json");
  try { const j = JSON.parse(fs.readFileSync(f, "utf8")); fs.rmSync(f, { force: true }); return j; } catch { return null; }
}

module.exports = { create, applyStaged, takeJustUpdated, cmp, verify, REPO, ASSET };
