// VantyX – Desktop-App (Electron)
"use strict";
const { app, BrowserWindow, WebContentsView, ipcMain, shell, net, session, Menu, dialog, screen } = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");

const PKG = require("./package.json");
const VERSION = PKG.versionLabel || PKG.version;
const ROOT = __dirname;
const UI = path.join(ROOT, "ui");
const BASE = process.env.APPDATA || path.join(os.homedir(), ".config");
const DATA = process.env.TC_DATA_DIR || path.join(BASE, "VantyX");
const LOCAL = "http://127.0.0.1:47822/";
const AUMID = "com.vantyx.app";
const TV_PART = "persist:tradingview";
const TV_HOME = "https://www.tradingview.com/chart/";
const TV_TEST = process.env.TC_TV_HOME || "";   // nur für Tests

// Daten der Beta "Trading Cockpit" übernehmen
if (!fs.existsSync(DATA) && fs.existsSync(path.join(BASE, "Trading Cockpit"))) {
  try { fs.cpSync(path.join(BASE, "Trading Cockpit"), DATA, { recursive: true, filter: s => !s.includes("app-profil") }); } catch {}
}
fs.mkdirSync(DATA, { recursive: true });
app.setPath("userData", path.join(DATA, "app"));
app.setAppUserModelId(AUMID);
app.commandLine.appendSwitch("disable-features", "Translate,MediaRouter");

// Geprüftes Update vom letzten Mal einspielen – nur die erste Instanz, bevor der Rest der App geladen ist
const updater = require("./updater");
const gotLock = app.requestSingleInstanceLock();
if (gotLock) {
  const ulog = m => { try { fs.appendFileSync(path.join(DATA, "vantyx.log"), new Date().toISOString().replace("T", " ").slice(0, 19) + " " + m + "\n"); } catch {} };
  if (updater.applyStaged({ root: ROOT, dataDir: DATA, currentVersion: PKG.version, log: ulog })) { app.releaseSingleInstanceLock(); app.relaunch(); app.exit(0); }
}

const backend = require("./backend");
const log = backend.log;
process.on("uncaughtException", e => log(`Unerwarteter Fehler: ${e && e.stack || e}`));

const early = m => { try { fs.appendFileSync(path.join(DATA, "vantyx.log"), new Date().toISOString().replace("T", " ").slice(0, 19) + " " + m + "\n"); } catch {} };

// ---------------------------------------------------------------- Journal aus VantyX 1.x übernehmen
// 1.x lief in einem Edge-Fenster; Trades, Importe und Notizen liegen im Speicher dieses Profils.
function migrateBrowserStorage() {
  const dst = path.join(app.getPath("userData"), "Local Storage", "leveldb");
  if (fs.existsSync(dst)) return;
  for (const prof of ["Default", "Profile 1"]) {
    const src = path.join(DATA, "app-profil", prof, "Local Storage", "leveldb");
    if (!fs.existsSync(src)) continue;
    try {
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      fs.cpSync(src, dst, { recursive: true, filter: s => path.basename(s) !== "LOCK" });
      early(`Journal aus VantyX 1.x übernommen (${prof}).`);
    } catch (e) { early(`Übernahme des Journals fehlgeschlagen: ${e.message}`); }
    return;
  }
}

// ---------------------------------------------------------------- Fensterposition merken
const WINFILE = path.join(DATA, "window.json");
function loadWinState() {
  const s = backend.loadJson(WINFILE, null);
  const d = { width: 1560, height: 980 };
  if (!s || !s.width) return d;
  const area = screen.getDisplayMatching({ x: s.x ?? 0, y: s.y ?? 0, width: s.width, height: s.height }).workArea;
  const visible = s.x != null && s.x < area.x + area.width - 80 && s.x + s.width > area.x + 80 && s.y >= area.y - 10 && s.y < area.y + area.height - 80;
  return { width: Math.min(s.width, area.width), height: Math.min(s.height, area.height), ...(visible ? { x: s.x, y: s.y } : {}), max: !!s.max };
}
function saveWinState(win) {
  try {
    const b = win.getNormalBounds();
    fs.writeFileSync(WINFILE, JSON.stringify({ ...b, max: win.isMaximized() }));
  } catch {}
}

// ---------------------------------------------------------------- Startmenü-Verknüpfung (nötig für Windows-Benachrichtigungen)
function ensureShortcuts() {
  if (process.platform !== "win32" || !app.isPackaged) return;
  const opts = { target: process.execPath, appUserModelId: AUMID, icon: path.join(UI, "nyxor-x3.ico"), iconIndex: 0, description: "Nyxor – Trade with clarity" };
  // seit 2.8: „Nyxor“ – alte VantyX-Verknüpfungen werden umbenannt
  const progs = path.join(app.getPath("appData"), "Microsoft", "Windows", "Start Menu", "Programs");
  const start = path.join(progs, "Nyxor.lnk"), oldStart = path.join(progs, "VantyX.lnk");
  try { shell.writeShortcutLink(start, fs.existsSync(start) ? "replace" : "create", opts); } catch (e) { log(`Verknüpfung: ${e.message}`); }
  try { if (fs.existsSync(start)) fs.rmSync(oldStart, { force: true }); } catch {}
  // an die Taskleiste angeheftete Verknüpfung auf das neue Icon umstellen (Name/Pin bleiben)
  try {
    const pins = path.join(app.getPath("appData"), "Microsoft", "Internet Explorer", "Quick Launch", "User Pinned", "TaskBar");
    for (const f of fs.existsSync(pins) ? fs.readdirSync(pins) : []) {
      if (!/\.lnk$/i.test(f)) continue;
      const lp = path.join(pins, f); let l = null; try { l = shell.readShortcutLink(lp); } catch {}
      if (l && l.target && path.resolve(l.target).toLowerCase() === path.resolve(process.execPath).toLowerCase() && l.icon !== opts.icon)
        shell.writeShortcutLink(lp, "update", { icon: opts.icon, iconIndex: 0, appUserModelId: AUMID, description: opts.description });
    }
  } catch (e) { log(`Taskleisten-Verknüpfung: ${e.message}`); }
  const deskDir = app.getPath("desktop"), desk = path.join(deskDir, "Nyxor.lnk"), oldDesk = path.join(deskDir, "VantyX.lnk");
  try {
    if (fs.existsSync(oldDesk)) { shell.writeShortcutLink(desk, fs.existsSync(desk) ? "replace" : "create", opts); if (fs.existsSync(desk)) fs.rmSync(oldDesk, { force: true }); }
    else if (fs.existsSync(desk)) shell.writeShortcutLink(desk, "replace", opts);
  } catch {}
}

// ---------------------------------------------------------------- TradingView im App-Fenster
let win = null, tv = null, tvShown = false, tvRect = null;
const TVFILE = path.join(DATA, "tradingview.json");
let OAUTH = /(^|\.)(tradingview\.com|accounts\.google\.com|google\.com|gstatic\.com|appleid\.apple\.com|apple\.com|facebook\.com|twitter\.com|x\.com|linkedin\.com|yahoo\.com)$/i;
if (process.env.TC_TV_TESTHOST) OAUTH = new RegExp(OAUTH.source.replace("$", "|^127\\.0\\.0\\.1$"), "i");   // nur für Tests
const isTvHost = h => /(^|\.)tradingview\.com$/i.test(h);
const hostOf = u => { try { return new URL(u).hostname; } catch { return ""; } };

function tvSession() {
  const s = session.fromPartition(TV_PART);
  if (!s.__vantyx) {
    s.__vantyx = true;
    s.setUserAgent(s.getUserAgent().replace(/\s?Electron\/[\d.]+/i, "").replace(/\s?vantyx\/[\d.]+/i, ""));
    const ok = new Set(["notifications", "clipboard-sanitized-write", "clipboard-read", "fullscreen"]);
    s.setPermissionRequestHandler((wc, perm, cb, d) => cb(ok.has(perm) && isTvHost(hostOf(d.requestingUrl || wc.getURL()))));
    s.setPermissionCheckHandler((wc, perm, origin) => ok.has(perm) && isTvHost(hostOf(origin)));
  }
  return s;
}

function tvState() {
  if (!win || !tv) return;
  const wc = tv.webContents;
  win.webContents.send("tv:state", { url: wc.getURL(), title: wc.getTitle(), loading: wc.isLoading(), back: wc.navigationHistory.canGoBack(), fwd: wc.navigationHistory.canGoForward() });
}

function guardContents(wc, isPopup) {
  wc.setWindowOpenHandler(({ url }) => {
    if (OAUTH.test(hostOf(url))) {
      return { action: "allow", overrideBrowserWindowOptions: { parent: win, width: 560, height: 720, autoHideMenuBar: true, backgroundColor: "#131722", title: "Anmelden – TradingView",
        icon: path.join(UI, process.platform === "win32" ? "nyxor-x3.ico" : "vantyx-256.png"), webPreferences: { partition: TV_PART, sandbox: true, contextIsolation: true } } };
    }
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  wc.on("will-navigate", (e, url) => {
    const h = hostOf(url);
    if (isPopup ? OAUTH.test(h) : (isTvHost(h) || OAUTH.test(h))) return;
    e.preventDefault();
    if (/^https?:/i.test(url)) shell.openExternal(url);
  });
  wc.on("did-create-window", w => { w.setMenuBarVisibility(false); guardContents(w.webContents, true); });
}

function ensureTv(url) {
  if (tv) return;
  tvSession();
  tv = new WebContentsView({ webPreferences: { partition: TV_PART, sandbox: true, contextIsolation: true, backgroundThrottling: false } });
  tv.setBackgroundColor("#131722");
  if (typeof tv.setBorderRadius === "function") tv.setBorderRadius(12);
  const wc = tv.webContents;
  guardContents(wc, false);
  const remember = () => { const u = wc.getURL(); if (isTvHost(hostOf(u)) && /\/chart\//.test(u)) { try { fs.writeFileSync(TVFILE, JSON.stringify({ url: u })); } catch {} } tvState(); };
  wc.on("did-navigate", remember); wc.on("did-navigate-in-page", remember);
  wc.on("did-start-loading", tvState); wc.on("did-stop-loading", tvState); wc.on("page-title-updated", tvState);
  wc.on("did-fail-load", (e, code, desc, url, main) => { if (main && code !== -3) { log(`TradingView lädt nicht: ${desc}`); win && win.webContents.send("tv:state", { error: desc }); } });
  wc.on("render-process-gone", () => { log("TradingView-Ansicht abgestürzt – wird neu geladen"); setTimeout(() => wc.reload(), 800); });
  wc.on("before-input-event", (e, i) => { if (i.type === "keyDown" && (i.key === "F5" || (i.control && i.key.toLowerCase() === "r"))) { wc.reload(); e.preventDefault(); } });
  const last = backend.loadJson(TVFILE, {}).url;
  wc.loadURL(TV_TEST || last || url || TV_HOME);
}

function applyTvBounds() {
  if (!tv || !tvRect || !win) return;
  const z = win.webContents.getZoomFactor();
  tv.setBounds({ x: Math.round(tvRect.x * z), y: Math.round(tvRect.y * z), width: Math.max(0, Math.round(tvRect.w * z)), height: Math.max(0, Math.round(tvRect.h * z)) });
}

// ---------------------------------------------------------------- Coinglass (Liquidations-Heatmap) im App-Fenster
const CG_PART = "persist:coinglass", CG_HOME = "https://www.coinglass.com/pro/futures/LiquidationHeatMap";
const isCgHost = h => /(^|\.)coinglass\.com$/i.test(h);
let cg = null, cgShown = false, cgRect = null;
function cgState(extra) {
  if (!win || !cg) return;
  const wc = cg.webContents;
  win.webContents.send("cg:state", { title: wc.getTitle(), loading: wc.isLoading(), back: wc.navigationHistory.canGoBack(), fwd: wc.navigationHistory.canGoForward(), ...(extra || {}) });
}
function ensureCg() {
  if (cg) return;
  const s = session.fromPartition(CG_PART);
  if (!s.__nyx) { s.__nyx = true; s.setUserAgent(s.getUserAgent().replace(/\s?Electron\/[\d.]+/i, "").replace(/\s?vantyx\/[\d.]+/i, ""));
    s.setPermissionRequestHandler((wc, perm, cb) => cb(perm === "clipboard-sanitized-write")); }
  cg = new WebContentsView({ webPreferences: { partition: CG_PART, sandbox: true, contextIsolation: true } });
  cg.setBackgroundColor("#0b0e14");
  if (typeof cg.setBorderRadius === "function") cg.setBorderRadius(12);
  const wc = cg.webContents;
  wc.setWindowOpenHandler(({ url }) => {
    const h = hostOf(url);
    if (OAUTH.test(h) || isCgHost(h)) return { action: "allow", overrideBrowserWindowOptions: { parent: win, width: 560, height: 720, autoHideMenuBar: true, backgroundColor: "#0b0e14", title: "Anmelden – Coinglass",
      icon: path.join(UI, process.platform === "win32" ? "nyxor-x3.ico" : "vantyx-256.png"), webPreferences: { partition: CG_PART, sandbox: true, contextIsolation: true } } };
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  wc.on("will-navigate", (e, url) => { const h = hostOf(url); if (isCgHost(h) || OAUTH.test(h)) return; e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); });
  wc.on("did-create-window", w => w.setMenuBarVisibility(false));
  ["did-navigate", "did-navigate-in-page", "did-start-loading", "did-stop-loading", "page-title-updated"].forEach(ev => wc.on(ev, () => cgState()));
  wc.on("did-fail-load", (e, code, desc, url, main) => { if (main && code !== -3) { log(`Coinglass lädt nicht: ${desc}`); cgState({ error: desc }); } });
  wc.on("render-process-gone", () => setTimeout(() => wc.reload(), 800));
  wc.loadURL(process.env.TC_CG_URL || CG_HOME);
}
function applyCgBounds() {
  if (!cg || !cgRect || !win) return;
  const z = win.webContents.getZoomFactor();
  cg.setBounds({ x: Math.round(cgRect.x * z), y: Math.round(cgRect.y * z), width: Math.max(0, Math.round(cgRect.w * z)), height: Math.max(0, Math.round(cgRect.h * z)) });
}
ipcMain.on("cg:show", (e, a) => {
  if (!win || e.sender !== win.webContents) return;
  cgRect = a && a.rect; ensureCg(); applyCgBounds();
  if (!cgShown) { win.contentView.addChildView(cg); cgShown = true; }
  cgState();
});
ipcMain.on("cg:bounds", (e, r) => { if (win && e.sender === win.webContents) { cgRect = r; applyCgBounds(); } });
ipcMain.on("cg:hide", e => { if (win && e.sender === win.webContents && cg && cgShown) { win.contentView.removeChildView(cg); cgShown = false; } });
ipcMain.on("cg:cmd", (e, a) => {
  if (!win || e.sender !== win.webContents || !cg) return;
  const wc = cg.webContents, cmd = a && a.cmd;
  if (cmd === "back" && wc.navigationHistory.canGoBack()) wc.navigationHistory.goBack();
  else if (cmd === "forward" && wc.navigationHistory.canGoForward()) wc.navigationHistory.goForward();
  else if (cmd === "reload") wc.reload();
  else if (cmd === "home") wc.loadURL(CG_HOME);
  else if (cmd === "external") shell.openExternal(isCgHost(hostOf(wc.getURL())) ? wc.getURL() : CG_HOME);
});

ipcMain.on("tv:show", (e, a) => {
  if (!win || e.sender !== win.webContents) return;
  tvRect = a && a.rect; ensureTv(a && a.url);
  applyTvBounds();
  if (!tvShown) { win.contentView.addChildView(tv); tvShown = true; }
  tvState();
});
ipcMain.on("tv:bounds", (e, r) => { if (win && e.sender === win.webContents) { tvRect = r; applyTvBounds(); } });
ipcMain.on("tv:hide", e => { if (win && e.sender === win.webContents && tv && tvShown) { win.contentView.removeChildView(tv); tvShown = false; } });
ipcMain.on("tv:cmd", (e, a) => {
  if (!win || e.sender !== win.webContents || !tv) return;
  const wc = tv.webContents, { cmd, arg } = a || {};
  if (cmd === "back" && wc.navigationHistory.canGoBack()) wc.navigationHistory.goBack();
  else if (cmd === "forward" && wc.navigationHistory.canGoForward()) wc.navigationHistory.goForward();
  else if (cmd === "reload") wc.reload();
  else if (cmd === "home") wc.loadURL(TV_HOME);
  else if (cmd === "external") shell.openExternal(isTvHost(hostOf(wc.getURL())) ? wc.getURL() : TV_HOME);
  else if (cmd === "symbol" && typeof arg === "string" && /^[A-Z0-9_:.!]{2,40}$/i.test(arg)) {
    const m = wc.getURL().match(/tradingview\.com\/chart\/([A-Za-z0-9]+)\//);
    wc.loadURL(`https://www.tradingview.com/chart/${m ? m[1] + "/" : ""}?symbol=${encodeURIComponent(arg)}`);
  }
});
ipcMain.on("win:focus", e => { if (win && e.sender === win.webContents) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });

// ---------------------------------------------------------------- Begrüßungsfenster beim Start
let splash = null, shown = false;
function createSplash() {
  let name = "";
  try { name = String((JSON.parse(fs.readFileSync(path.join(DATA, "config.json"), "utf8")) || {}).name || "").slice(0, 30); } catch {}
  splash = new BrowserWindow({ width: 540, height: 340, frame: false, transparent: true, resizable: false, movable: true, show: false, center: true,
    skipTaskbar: true, alwaysOnTop: false, backgroundColor: "#00000000", hasShadow: false, title: "Nyxor",
    icon: path.join(UI, process.platform === "win32" ? "nyxor-x3.ico" : "vantyx-256.png"),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false } });
  splash.loadFile(path.join(UI, "splash.html"), { query: { n: name } }).catch(() => {});
  splash.once("ready-to-show", () => { if (splash && !shown) splash.show(); });
  splash.on("closed", () => { splash = null; });
}
function revealMain() {
  if (shown || !win) return; shown = true;
  const st = win.__st || {};
  if (process.platform === "win32") win.setOpacity(0);
  if (st.max) win.maximize();
  win.show(); win.focus();
  if (process.platform === "win32") { let o = 0; const t = setInterval(() => { o = Math.min(1, o + 0.12); if (win && !win.isDestroyed()) win.setOpacity(o); if (o >= 1) clearInterval(t); }, 16); }
  if (splash && !splash.isDestroyed()) { splash.webContents.executeJavaScript("document.body.classList.add('out')").catch(() => {}); setTimeout(() => { if (splash && !splash.isDestroyed()) splash.close(); }, 320); }
}
ipcMain.on("app:ready", e => { if (win && e.sender === win.webContents) setTimeout(revealMain, 60); });

// ---------------------------------------------------------------- Hauptfenster
function createWindow(url) {
  const st = loadWinState();
  // bei maximiertem Fenster gleich in voller Größe aufbauen – kein „erst klein, dann groß“
  let bounds = { width: st.width, height: st.height, ...(st.x != null ? { x: st.x, y: st.y } : {}) };
  if (st.max) { const area = screen.getDisplayMatching({ x: st.x ?? 0, y: st.y ?? 0, width: st.width, height: st.height }).workArea; bounds = { x: area.x, y: area.y, width: area.width, height: area.height }; }
  win = new BrowserWindow({
    ...bounds,
    minWidth: 980, minHeight: 640, show: false, backgroundColor: "#07070b", title: "Nyxor",
    icon: path.join(UI, process.platform === "win32" ? "nyxor-x3.ico" : "vantyx-256.png"),
    titleBarStyle: "hidden", titleBarOverlay: { color: "#00000000", symbolColor: "#c4b5fd", height: 36 },
    webPreferences: { preload: path.join(ROOT, "preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, spellcheck: false },
  });
  const wc = win.webContents;
  wc.setWindowOpenHandler(({ url: u }) => { if (/^https?:/i.test(u) && !u.startsWith(LOCAL)) shell.openExternal(u); return { action: "deny" }; });
  wc.on("will-navigate", (e, u) => { if (!u.startsWith(LOCAL)) { e.preventDefault(); if (/^https?:/i.test(u)) shell.openExternal(u); } });
  wc.on("before-input-event", (e, i) => {
    if (i.type !== "keyDown") return;
    const k = i.key.toLowerCase(), c = i.control || i.meta;
    if (k === "f5" || (c && k === "r")) { wc.reload(); e.preventDefault(); }
    else if (c && i.shift && k === "i") { wc.toggleDevTools(); e.preventDefault(); }
    else if (k === "f11") { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (c && (k === "+" || k === "=" || k === "-" || k === "0")) {
      const z = wc.getZoomFactor(); wc.setZoomFactor(k === "0" ? 1 : Math.min(1.6, Math.max(0.6, z + (k === "-" ? -0.1 : 0.1))));
      e.preventDefault();
    }
  });
  wc.on("render-process-gone", (e, d) => { log(`Fenster abgestürzt (${d.reason}) – lade neu`); setTimeout(() => wc.reload(), 600); });
  win.__st = st;
  win.once("ready-to-show", () => setTimeout(revealMain, 2500));   // Sicherheitsnetz, falls die Oberfläche kein „bereit“ meldet
  setTimeout(revealMain, 9000);
  win.on("close", () => saveWinState(win));
  wireMini();
  win.on("closed", () => { win = null; tv = null; tvShown = false; });
  wc.loadURL(url);
}

// ---------------------------------------------------------------- Mini-Fenster (unten rechts, solange Nyxor minimiert ist)
let mini = null, miniOn = true, miniData = null, miniDismissed = false;
const MINIFILE = path.join(DATA, "mini.json");
function miniBounds() {
  const W = 290, H = 158, st = backend.loadJson(MINIFILE, {});
  const area = screen.getPrimaryDisplay().workArea;
  if (st.x != null) { const d = screen.getDisplayMatching({ x: st.x, y: st.y, width: W, height: H }).workArea;
    if (st.x >= d.x && st.y >= d.y && st.x + W <= d.x + d.width && st.y + H <= d.y + d.height) return { x: st.x, y: st.y, width: W, height: H }; }
  return { x: area.x + area.width - W - 14, y: area.y + area.height - H - 14, width: W, height: H };
}
function ensureMini() {
  if (mini && !mini.isDestroyed()) return mini;
  mini = new BrowserWindow({ ...miniBounds(), frame: false, transparent: true, resizable: false, maximizable: false, minimizable: false, fullscreenable: false,
    skipTaskbar: true, alwaysOnTop: true, show: false, hasShadow: false, title: "Nyxor Mini", backgroundColor: "#00000000",
    webPreferences: { preload: path.join(ROOT, "preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false } });
  mini.setAlwaysOnTop(true, "floating");
  mini.loadFile(path.join(UI, "mini.html")).catch(() => {});
  mini.webContents.on("did-finish-load", () => { if (miniData) mini.webContents.send("mini:data", miniData); });
  mini.on("moved", () => { try { const b = mini.getBounds(); fs.writeFileSync(MINIFILE, JSON.stringify({ x: b.x, y: b.y })); } catch {} });
  mini.on("closed", () => { mini = null; });
  return mini;
}
function showMini() { if (!miniOn || miniDismissed || !win || win.isDestroyed()) return; const m = ensureMini(); if (!m.isVisible()) m.showInactive(); }
function hideMini() { if (mini && !mini.isDestroyed() && mini.isVisible()) mini.hide(); }
function wireMini() {
  if (!win) return;
  win.on("minimize", () => { miniDismissed = false; showMini(); });
  ["restore", "show", "focus"].forEach(ev => win.on(ev, hideMini));
  win.on("closed", () => { if (mini && !mini.isDestroyed()) mini.close(); });
}
ipcMain.on("mini:data", (e, d) => {
  if (!win || e.sender !== win.webContents || !d || typeof d !== "object") return;
  miniData = d; if (typeof d.on === "boolean") { miniOn = d.on; if (!miniOn) hideMini(); else if (win.isMinimized()) showMini(); }
  if (mini && !mini.isDestroyed()) mini.webContents.send("mini:data", d);
});
ipcMain.on("mini:restore", e => { if (mini && e.sender === mini.webContents && win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
ipcMain.on("mini:close", e => { if (mini && e.sender === mini.webContents) { miniDismissed = true; hideMini(); } });

// ---------------------------------------------------------------- Start
// ---------------------------------------------------------------- Musik („Läuft gerade“)
const media = require("./media").create({ log: m => log(m), onState: s => { if (win && !win.isDestroyed()) win.webContents.send("media:state", s); } });
ipcMain.handle("media:sub", e => (win && e.sender === win.webContents) ? media.subscribe() : null);
ipcMain.on("media:unsub", e => { if (win && e.sender === win.webContents) media.unsubscribe(); });
ipcMain.on("media:cmd", (e, c) => { if (win && e.sender === win.webContents) media.cmd(String(c)); });
app.on("will-quit", () => media.stop());

// ---------------------------------------------------------------- Updates
let upd = null, justUpdated = null;
const sendUpd = s => { if (win && !win.isDestroyed()) win.webContents.send("upd:state", { ...s, currentLabel: VERSION }); };
ipcMain.handle("upd:get", e => (win && e.sender === win.webContents && upd) ? { ...upd.get(), currentLabel: VERSION, justUpdated: (() => { const j = justUpdated; justUpdated = null; return j; })() } : null);
ipcMain.handle("upd:check", async e => (win && e.sender === win.webContents && upd) ? { ...(await upd.check(true)), currentLabel: VERSION } : null);
ipcMain.on("upd:install", e => {
  if (!win || e.sender !== win.webContents || !upd) return;
  const s = upd.get();
  if (s.state === "ready") { log(`Neustart für Update ${s.version}`); app.relaunch(); app.quit(); }
  else if (s.state === "setup" && /^https:\/\/(github\.com|raw\.githubusercontent\.com)\//.test(s.url || "")) shell.openExternal(s.url);
});

if (!gotLock) {
  app.quit();
} else {
  migrateBrowserStorage();          // muss vor dem ersten Zugriff auf den Speicher passieren
  app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
  app.whenReady().then(async () => {
    Menu.setApplicationMenu(null);
    session.defaultSession.setPermissionRequestHandler((wc, perm, cb, d) => cb(perm === "notifications" && String(d.requestingUrl || "").startsWith(LOCAL)));
    createSplash();
    session.defaultSession.setPermissionCheckHandler((wc, perm, origin) => perm === "notifications" && String(origin || "").startsWith(LOCAL.slice(0, -1)));
    let started;
    try {
      started = await backend.start({ dataDir: DATA, uiDir: UI, version: VERSION, fetch: (u, o) => net.fetch(u, o), openExternal: u => shell.openExternal(u) });
    } catch (e) {
      log(`Start fehlgeschlagen: ${e.message}`);
      dialog.showErrorBox("Nyxor", e.code === "EADDRINUSE"
        ? "Nyxor ist schon geöffnet – oder eine ältere Version (1.x) läuft noch im Hintergrund.\n\nBitte schließe sie (notfalls PC neu starten) und öffne Nyxor erneut."
        : `Nyxor konnte nicht starten:\n${e.message}`);
      app.quit(); return;
    }
    ensureShortcuts();
    justUpdated = updater.takeJustUpdated(DATA);
    upd = updater.create({ root: ROOT, dataDir: DATA, currentVersion: PKG.version, electronVersion: process.versions.electron,
      fetch: (u, o) => net.fetch(u, o), log, onState: sendUpd });
    upd.schedule(+process.env.TC_UPDATE_DELAY || 15000, 6 * 3600 * 1000);
    createWindow(started.url);
  });
  app.on("window-all-closed", () => app.quit());
}
