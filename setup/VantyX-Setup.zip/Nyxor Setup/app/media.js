// VantyX – "Läuft gerade": liest die Windows-Mediensteuerung (Spotify, YouTube, …) und steuert Play/Pause/Weiter.
// Ein einziger, unsichtbarer PowerShell-Prozess läuft im Hintergrund, solange das Musik-Widget sichtbar ist.
"use strict";
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const CMDFILE = path.join(os.tmpdir(), "vantyx-media-cmd.txt");

const PS = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
function Say($o) { [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress)); [Console]::Out.Flush() }
Say @{ ok = $true; boot = 1; has = $false }
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$opName = 'IAsyncOperation' + [char]96 + '1'
$m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq $opName } | Select-Object -First 1
if (-not $m) { Say @{ ok = $false; err = 'AsTask nicht gefunden' }; exit }
function Await($op, [Type]$t) { $task = $m.MakeGenericMethod($t).Invoke($null, @($op)); [void]$task.Wait(4000); return $task.Result }
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
if (-not $mgr) { Say @{ ok = $false; err = 'Windows-Mediensteuerung nicht verfuegbar: ' + [string]$Error[0] }; exit }
$cmdFile = $env:VX_MEDIA_CMD
$last = ''; $lastArtKey = ''; $art = ''
function Pick() {
  $all = @($mgr.GetSessions())
  $best = $null
  foreach ($x in $all) { if ([string]$x.GetPlaybackInfo().PlaybackStatus -eq 'Playing') { if (-not $best -or ([string]$x.SourceAppUserModelId) -like '*spotify*') { $best = $x } } }
  if (-not $best) { foreach ($x in $all) { if (([string]$x.SourceAppUserModelId) -like '*spotify*') { $best = $x } } }
  if (-not $best) { $best = $mgr.GetCurrentSession() }
  if (-not $best -and $all.Count) { $best = $all[0] }
  return @($best, $all.Count)
}
while ($true) {
  if ($cmdFile -and (Test-Path -LiteralPath $cmdFile)) {
    $cmd = (Get-Content -LiteralPath $cmdFile -Raw).Trim(); Remove-Item -LiteralPath $cmdFile -Force
    if ($cmd -eq 'quit') { exit }
    $s = (Pick)[0]
    if ($s) {
      if ($cmd -eq 'toggle') { [void](Await ($s.TryTogglePlayPauseAsync()) ([bool])) }
      elseif ($cmd -eq 'next') { [void](Await ($s.TrySkipNextAsync()) ([bool])) }
      elseif ($cmd -eq 'prev') { [void](Await ($s.TrySkipPreviousAsync()) ([bool])) }
      Start-Sleep -Milliseconds 250
    }
    $last = ''
  }
  $o = @{ ok = $true; has = $false; n = 0 }
  try {
    $r = Pick; $s = $r[0]; $o.n = [int]$r[1]
    if ($s) {
      $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
      $pb = $s.GetPlaybackInfo()
      $o.has = $true; $o.app = [string]$s.SourceAppUserModelId
      $o.title = [string]$p.Title; $o.artist = [string]$p.Artist; $o.album = [string]$p.AlbumTitle
      $o.status = [string]$pb.PlaybackStatus
      $key = $o.app + '|' + $o.title + '|' + $o.artist
      if ($key -ne $lastArtKey) {
        $lastArtKey = $key; $art = ''
        try {
          if ($p.Thumbnail) {
            $st = Await ($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
            if ($st -and $st.Size -gt 0 -and $st.Size -lt 2000000) {
              $rd = [Windows.Storage.Streams.DataReader]::new($st.GetInputStreamAt(0))
              [void](Await ($rd.LoadAsync([uint32]$st.Size)) ([uint32]))
              $b = New-Object byte[] ([int]$st.Size); $rd.ReadBytes($b)
              $art = 'data:' + $st.ContentType + ';base64,' + [Convert]::ToBase64String($b)
            }
          }
        } catch { $art = '' }
      }
      $o.art = $art
    }
  } catch { $o = @{ ok = $false; has = $false; err = [string]$_ } }
  $j = $o | ConvertTo-Json -Compress
  if ($j -ne $last) { $last = $j; Say $o }
  Start-Sleep -Milliseconds 700
}
`;

function create({ log, onState }) {
  let seen = 0, ps = null, buf = "", subs = 0, stopT = null, state = { ok: process.platform === "win32", has: false, unsupported: process.platform !== "win32" };
  const emit = s => { state = s; try { onState(s); } catch {} };

  function start() {
    if (ps || process.platform !== "win32") return;
    try {
      const enc = Buffer.from(PS, "utf16le").toString("base64");
      ps = spawn("powershell.exe", ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
        { windowsHide: true, stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, VX_MEDIA_CMD: CMDFILE } });
    } catch (e) { log(`Musik-Widget: PowerShell nicht startbar – ${e.message}`); ps = null; return; }
    ps.stdout.setEncoding("utf8");
    ps.stdout.on("data", d => {
      buf += d; let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith("{")) continue;
        try { const j = JSON.parse(line); if (j.ok === false) log("Musik-Widget: " + (j.err || "Fehler")); if (j.boot) { log("Musik-Widget: PowerShell bereit"); continue; } if (!seen++) log("Musik-Widget: erste Antwort, " + (j.n || 0) + " Medienquelle(n), " + (j.has ? (j.app || "?") : "nichts aktiv")); emit({ ok: j.ok !== false, err: j.err || "", n: j.n || 0, has: !!j.has, app: j.app || "", title: j.title || "", artist: j.artist || "", album: j.album || "", status: j.status || "", art: j.art || "" }); } catch {}
      }
    });
    let errN = 0; ps.stderr.setEncoding("utf8");
    ps.stderr.on("data", d => { if (errN++ < 5) log("Musik-Widget (PowerShell): " + String(d).trim().slice(0, 400)); });
    ps.on("exit", code => { if (code) log("Musik-Widget: PowerShell beendet mit Code " + code); ps = null; buf = ""; });
    log("Musik-Widget gestartet");
  }
  function stop() { if (!ps) return; const p = ps; ps = null; try { p.kill(); } catch {} try { fs.rmSync(CMDFILE, { force: true }); } catch {} }

  return {
    subscribe() { subs++; clearTimeout(stopT); start(); return state; },
    unsubscribe() { subs = Math.max(0, subs - 1); if (!subs) { clearTimeout(stopT); stopT = setTimeout(stop, 30000); } },
    cmd(c) { if (ps && ["toggle", "next", "prev"].includes(c)) { try { fs.writeFileSync(CMDFILE, c); } catch {} } },
    get: () => state,
    stop,
  };
}

module.exports = { create, PS };
