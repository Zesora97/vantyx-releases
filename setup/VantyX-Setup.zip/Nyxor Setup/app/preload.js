// Brücke zwischen VantyX-Oberfläche und App – nur diese Funktionen sind erreichbar
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("vantyx", {
  isApp: true,
  platform: process.platform,
  tv: {
    show: (rect, url) => ipcRenderer.send("tv:show", { rect, url }),
    bounds: rect => ipcRenderer.send("tv:bounds", rect),
    hide: () => ipcRenderer.send("tv:hide"),
    cmd: (cmd, arg) => ipcRenderer.send("tv:cmd", { cmd, arg }),
    onState: fn => ipcRenderer.on("tv:state", (_e, s) => fn(s)),
  },
  cg: {
    show: rect => ipcRenderer.send("cg:show", { rect }),
    bounds: rect => ipcRenderer.send("cg:bounds", rect),
    hide: () => ipcRenderer.send("cg:hide"),
    cmd: cmd => ipcRenderer.send("cg:cmd", { cmd }),
    onState: fn => ipcRenderer.on("cg:state", (_e, s) => fn(s)),
  },
  mini: {
    push: d => ipcRenderer.send("mini:data", d),
    onData: fn => ipcRenderer.on("mini:data", (_e, d) => fn(d)),
    restore: () => ipcRenderer.send("mini:restore"),
    close: () => ipcRenderer.send("mini:close"),
  },
  focus: () => ipcRenderer.send("win:focus"),
  ready: () => ipcRenderer.send("app:ready"),
  media: {
    sub: () => ipcRenderer.invoke("media:sub"),
    unsub: () => ipcRenderer.send("media:unsub"),
    cmd: c => ipcRenderer.send("media:cmd", c),
    onState: fn => ipcRenderer.on("media:state", (_e, s) => fn(s)),
  },
  update: {
    get: () => ipcRenderer.invoke("upd:get"),
    check: () => ipcRenderer.invoke("upd:check"),
    install: () => ipcRenderer.send("upd:install"),
    onState: fn => ipcRenderer.on("upd:state", (_e, s) => fn(s)),
  },
});
