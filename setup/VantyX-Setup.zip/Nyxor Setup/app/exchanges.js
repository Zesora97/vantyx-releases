// VantyX – Börsen-Anbindungen (abgeschlossene Positionen → einheitliches Trade-Format)
"use strict";
const crypto = require("node:crypto");

const DAY = 864e5;

const EXCHANGES = {
  // api: true = automatischer Abgleich eingebaut · alle anderen: Import per CSV-Datei
  bitunix:  { name: "Bitunix", api: true, trade_url: "https://www.bitunix.com/contract-trade/BTCUSDT",
              key_url: "https://www.bitunix.com/account/apiManagement" },
  bybit:    { name: "Bybit", api: true, base: "https://api.bybit.com",
              trade_url: "https://www.bybit.com/trade/usdt/BTCUSDT", key_url: "https://www.bybit.com/app/user/api-management" },
  bybit_eu: { name: "Bybit EU", api: true, base: "https://api.bybit.eu",
              trade_url: "https://www.bybit.eu/trade/usdt/BTCUSDT", key_url: "https://www.bybit.eu/app/user/api-management" },
  binance:  { name: "Binance", api: false, trade_url: "https://www.binance.com" },
  okx:      { name: "OKX", api: true, pass: true, trade_url: "https://www.okx.com",
              key_url: "https://www.okx.com/account/my-api" },
  bitget:   { name: "Bitget", api: false, trade_url: "https://www.bitget.com" },
  kraken:   { name: "Kraken", api: false, trade_url: "https://www.kraken.com" },
  coinbase: { name: "Coinbase Advanced", api: false, trade_url: "https://www.coinbase.com/advanced-trade" },
  kucoin:   { name: "KuCoin", api: false, trade_url: "https://www.kucoin.com" },
  gate:     { name: "Gate.io", api: false, trade_url: "https://www.gate.io" },
  mexc:     { name: "MEXC", api: false, trade_url: "https://www.mexc.com" },
  bingx:    { name: "BingX", api: false, trade_url: "https://bingx.com" },
  phemex:   { name: "Phemex", api: false, trade_url: "https://phemex.com" },
  deribit:  { name: "Deribit", api: false, trade_url: "https://www.deribit.com" },
  bitstamp: { name: "Bitstamp", api: false, trade_url: "https://www.bitstamp.net" },
  cryptocom:{ name: "Crypto.com Exchange", api: false, trade_url: "https://crypto.com/exchange" },
  whitebit: { name: "WhiteBIT", api: false, trade_url: "https://whitebit.com" },
  bitmart:  { name: "BitMart", api: false, trade_url: "https://www.bitmart.com" },
  htx:      { name: "HTX", api: false, trade_url: "https://www.htx.com" },
  pionex:   { name: "Pionex", api: false, trade_url: "https://www.pionex.com" },
  ascendex: { name: "AscendEX", api: false, trade_url: "https://ascendex.com" },
  lbank:    { name: "LBank", api: false, trade_url: "https://www.lbank.com" },
  xt:       { name: "XT.COM", api: false, trade_url: "https://www.xt.com" },
  manual:   { name: "Andere Börse", api: false, trade_url: "", custom: true },
};

class ExchangeError extends Error {}

let httpFetch = (...a) => fetch(...a);           // in der App: Electron net.fetch (System-Proxy, Windows-Zertifikate)
function setFetch(fn) { httpFetch = fn; }

const sleep = ms => new Promise(r => setTimeout(r, ms));
const num = (v, d = 0) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };
const iso = ms => new Date(Math.trunc(num(ms))).toISOString();
const sha256 = s => crypto.createHash("sha256").update(s).digest("hex");

async function httpGet(url, headers) {
  let r;
  try {
    const ctl = AbortSignal.timeout(20000);
    r = await httpFetch(url, { headers: { ...headers, "User-Agent": "vantyx/2.0" }, signal: ctl });
  } catch (e) {
    throw new ExchangeError(`Keine Verbindung zur Börse (${e.cause?.code || e.message})`);
  }
  const text = await r.text();
  if (!r.ok) throw new ExchangeError(`HTTP ${r.status} ${text.slice(0, 200)}`.trim());
  try { return JSON.parse(text); } catch { throw new ExchangeError("Ungültige Antwort der Börse"); }
}

function direction(entry, exit, qty, gross, fallback) {
  const move = (exit - entry) * qty;
  if (Math.abs(gross) > 1e-9 && Math.abs(move) > 1e-9) return (move > 0) === (gross > 0) ? "long" : "short";
  return fallback;
}
const trade = kw => ({ tf: "", setup: "", emotion: "", rulesOk: true, mistakes: [], note: "", stop: "", pnlManual: "", ...kw });
const r6 = v => Math.round(v * 1e6) / 1e6, r2 = v => Math.round(v * 100) / 100;

// ---------------------------------------------------------------- Bitunix
async function bitunixGet(cfg, params) {
  const keys = Object.keys(params).sort();
  const qp = keys.map(k => k + params[k]).join("");
  const nonce = crypto.randomUUID().replace(/-/g, "");
  const ts = String(Date.now());
  const sign = sha256(sha256(nonce + ts + cfg.api_key + qp) + cfg.secret_key);
  const qs = keys.map(k => encodeURIComponent(k) + "=" + encodeURIComponent(params[k])).join("&");
  const base = process.env.TC_BITUNIX_BASE || "https://fapi.bitunix.com";
  const j = await httpGet(`${base}/api/v1/futures/position/get_history_positions?${qs}`,
    { "api-key": cfg.api_key, nonce, timestamp: ts, sign, language: "en-US", "Content-Type": "application/json" });
  if (String(j.code) !== "0") throw new ExchangeError(`Bitunix: ${j.msg || JSON.stringify(j)}`);
  return j.data || {};
}

async function bitunixFetch(cfg, sinceMs, maxPages = 60) {
  const out = []; let skip = 0;
  for (let i = 0; i < maxPages; i++) {
    const data = await bitunixGet(cfg, { limit: 100, skip, startTime: Math.trunc(sinceMs) });
    const page = data.positionList || [];
    out.push(...page); skip += page.length;
    const total = parseInt(data.total || 0, 10);
    if (!page.length || page.length < 100 || (total && skip >= total)) break;
    await sleep(250);
  }
  return Object.fromEntries(out.map(p => ["bitunix_" + p.positionId, p]));
}

function bitunixNormalize(p) {
  const net = num(p.realizedPNL);                // geprüft: bereits netto (Gebühren + Funding enthalten)
  const fee = Math.abs(num(p.fee)), funding = num(p.funding);
  const gross = net + fee - funding;
  const qty = num(p.maxQty), entry = num(p.entryPrice), exit = num(p.closePrice);
  const fallback = String(p.side || "").toUpperCase() === "SHORT" ? "short" : "long";
  return trade({ k: "api_" + String(p.positionId ?? "").replace(/[^A-Za-z0-9]/g, ""),
    date: iso(p.ctime), closeDate: iso(p.mtime || p.ctime), account: "Bitunix", src: "bitunix-api", symbol: p.symbol || "",
    dir: direction(entry, exit, qty, gross, fallback), entry, exit, qty, notional: r2(qty * exit),
    gross: r6(gross), fees: r6(fee), funding: r6(funding), pnl: r6(net) });
}

// ---------------------------------------------------------------- Bybit (global / EU)
async function bybitGet(cfg, base, path, params) {
  const qs = new URLSearchParams(params).toString();
  const ts = String(Date.now()), rw = "10000";
  const sign = crypto.createHmac("sha256", cfg.secret_key).update(ts + cfg.api_key + rw + qs).digest("hex");
  const j = await httpGet(`${base}${path}?${qs}`, { "X-BAPI-API-KEY": cfg.api_key, "X-BAPI-TIMESTAMP": ts, "X-BAPI-RECV-WINDOW": rw, "X-BAPI-SIGN": sign });
  if (j.retCode !== 0) throw new ExchangeError(`Bybit: ${j.retMsg || JSON.stringify(j)}`);
  return j.result || {};
}

async function bybitFetch(cfg, sinceMs, base) {
  const out = {}; const now = Date.now();
  let start = Math.max(Math.trunc(sinceMs), now - 729 * DAY);   // Bybit liefert max. 2 Jahre
  while (start < now) {
    const end = Math.min(start + 7 * DAY - 1, now);
    let cursor = "";
    for (let i = 0; i < 50; i++) {
      const params = { category: "linear", startTime: start, endTime: end, limit: 100 };
      if (cursor) params.cursor = cursor;
      const res = await bybitGet(cfg, base, "/v5/position/closed-pnl", params);
      for (const p of res.list || []) out[`bybit_${p.orderId}_${p.updatedTime}`] = p;
      cursor = res.nextPageCursor || "";
      if (!cursor || !(res.list || []).length) break;
      await sleep(120);
    }
    start = end + 1;
    await sleep(120);
  }
  return out;
}

function bybitNormalize(p, account = "Bybit") {
  const net = num(p.closedPnl);
  const fee = Math.abs(num(p.openFee)) + Math.abs(num(p.closeFee));
  const gross = net + fee;
  const qty = num(p.closedSize || p.qty), entry = num(p.avgEntryPrice), exit = num(p.avgExitPrice);
  const fallback = String(p.side || "").toLowerCase() === "sell" ? "long" : "short";   // Schließ-Order: Sell schließt Long
  return trade({ k: "bybit_" + (String(p.orderId ?? "") + String(p.updatedTime ?? "")).replace(/[^A-Za-z0-9]/g, ""),
    date: iso(p.updatedTime || p.createdTime), closeDate: "", account, src: "bybit-api", symbol: p.symbol || "",
    dir: direction(entry, exit, qty, gross, fallback), entry, exit, qty, notional: r2(num(p.cumExitValue) || qty * exit),
    gross: r6(gross), fees: r6(fee), funding: 0, pnl: r6(net) });
}

// ---------------------------------------------------------------- OKX (weltweit / EU / USA – Server wird automatisch gefunden)
const OKX_HOSTS = ["https://www.okx.com", "https://eea.okx.com", "https://us.okx.com"];
const okxHostFor = new Map();     // API-Key-Ende → funktionierender Server
let okxInst = { at: 0, map: {} };

async function okxGet(cfg, host, path, params) {
  const qs = new URLSearchParams(params).toString(), rp = path + (qs ? "?" + qs : "");
  const ts = new Date().toISOString();
  const sign = crypto.createHmac("sha256", cfg.secret_key).update(ts + "GET" + rp).digest("base64");
  const j = await httpGet(host + rp, { "OK-ACCESS-KEY": cfg.api_key, "OK-ACCESS-SIGN": sign, "OK-ACCESS-TIMESTAMP": ts,
    "OK-ACCESS-PASSPHRASE": cfg.passphrase || "", "Content-Type": "application/json" }).catch(e => {
    // OKX meldet falsche Schlüssel mit HTTP 401 + JSON – den Code durchreichen
    let j = null; try { j = JSON.parse(String(e.message).replace(/^HTTP \d+ /, "")); } catch {}
    if (j && j.code) throw new ExchangeError(`OKX ${j.code}: ${j.msg || ""}`); throw e; });
  if (String(j.code) !== "0") throw new ExchangeError(`OKX ${j.code}: ${j.msg || ""}`);
  return j.data || [];
}
async function okxCall(cfg, path, params) {
  if (!cfg.passphrase) throw new ExchangeError("OKX braucht zusätzlich die Passphrase deines API-Schlüssels.");
  const key = String(cfg.api_key).slice(-6), known = okxHostFor.get(key);
  const hosts = process.env.TC_OKX_BASE ? [process.env.TC_OKX_BASE] : known ? [known, ...OKX_HOSTS.filter(h => h !== known)] : OKX_HOSTS;
  let last;
  for (const h of hosts) {
    try { const d = await okxGet(cfg, h, path, params); okxHostFor.set(key, h); return d; }
    catch (e) { last = e; if (!/OKX (50101|50119|50105|50111)\b/.test(e.message)) throw e; }   // Schlüssel gehört zu anderem OKX-Server → nächsten probieren
  }
  throw last;
}
async function okxInstruments() {
  if (Date.now() - okxInst.at < 12 * 3600e3 && Object.keys(okxInst.map).length) return okxInst.map;
  const map = {};
  for (const t of ["SWAP", "FUTURES"]) {
    try { const j = await httpGet(`${process.env.TC_OKX_BASE || OKX_HOSTS[0]}/api/v5/public/instruments?instType=${t}`, {});
      for (const i of j.data || []) map[i.instId] = { ctVal: num(i.ctVal, 1), ctType: i.ctType || "linear" }; } catch {}
  }
  okxInst = { at: Date.now(), map }; return map;
}
async function okxFetch(cfg, sinceMs) {
  const out = {}, inst = await okxInstruments();
  for (const instType of ["SWAP", "FUTURES"]) {
    let after = "";
    for (let i = 0; i < 60; i++) {
      const params = { instType, limit: 100 }; if (after) params.after = after;
      const page = await okxCall(cfg, "/api/v5/account/positions-history", params);
      for (const p of page) { const c = inst[p.instId] || {}; out[`okx_${p.posId}_${p.uTime}`] = { ...p, _ctVal: c.ctVal || 1, _ctType: c.ctType || "linear" }; }
      if (page.length < 100) break;
      const oldest = Math.min(...page.map(p => num(p.uTime, Date.now())));
      if (oldest < sinceMs) break;
      after = String(oldest); await sleep(250);
    }
  }
  return out;
}
function okxNormalize(p) {
  const net = num(p.realizedPnl), fee = Math.abs(num(p.fee)), funding = num(p.fundingFee);
  const entry = num(p.openAvgPx), exit = num(p.closeAvgPx), n = num(p.closeTotalPos);
  const qty = p._ctType === "inverse" ? (exit ? n * num(p._ctVal, 1) / exit : 0) : n * num(p._ctVal, 1);
  const gross = num(p.pnl, net + fee - funding);
  const fb = String(p.direction || p.posSide || "").toLowerCase() === "short" ? "short" : "long";
  const sym = String(p.instId || "").replace(/-(SWAP|\d{6})$/, "").replace(/-/g, "");
  return trade({ k: "okx_" + (String(p.posId ?? "") + String(p.uTime ?? "")).replace(/[^A-Za-z0-9]/g, ""),
    date: iso(p.cTime || p.uTime), closeDate: iso(p.uTime || p.cTime), account: "OKX", src: "okx-api", symbol: sym,
    dir: direction(entry, exit, qty, gross, fb), entry, exit, qty: r6(qty), notional: r2(qty * exit),
    gross: r6(gross), fees: r6(fee), funding: r6(funding), pnl: r6(net) });
}

// ---------------------------------------------------------------- gemeinsame Schnittstelle
function fetchTrades(exchange, cfg, sinceMs) {
  if (exchange === "bitunix") return bitunixFetch(cfg, sinceMs);
  if (exchange === "bybit" || exchange === "bybit_eu") return bybitFetch(cfg, sinceMs, process.env.TC_BYBIT_BASE || EXCHANGES[exchange].base);
  if (exchange === "okx") return okxFetch(cfg, sinceMs);
  return Promise.resolve({});
}
function normalize(exchange, raw) {
  if (exchange === "bitunix") return bitunixNormalize(raw);
  if (exchange === "bybit" || exchange === "bybit_eu") return bybitNormalize(raw, EXCHANGES[exchange].name);
  if (exchange === "okx") return okxNormalize(raw);
  throw new Error(exchange);
}
const rawTime = (exchange, raw) => Math.trunc(num(exchange === "bitunix" ? raw.ctime : exchange === "okx" ? raw.uTime : raw.updatedTime, 0));

function friendlyError(msg) {
  const m = String(msg && msg.message || msg).toLowerCase();
  if (m.includes("passphrase")) return /50105/.test(m) ? "Passphrase stimmt nicht – bitte die Passphrase deines OKX-API-Schlüssels prüfen." : String(msg.message || msg);
  if (/okx (50113|50114)/.test(m)) return "Signatur ungültig – bitte Secret Key prüfen.";
  if (/okx (50111|50119|50101)/.test(m)) return "API Key ungültig oder abgelaufen.";
  if (/okx 50110/.test(m)) return "Deine IP-Adresse ist für diesen Schlüssel nicht freigegeben.";
  if (/okx (50102|50112)/.test(m)) return "Die Uhrzeit deines PCs weicht ab – bitte Windows-Uhr synchronisieren.";
  if (/okx 50120|okx 50030/.test(m)) return "Dem Schlüssel fehlt die Leseberechtigung („Lesen“ aktivieren).";
  if (m.includes("sign")) return "Signatur ungültig – bitte Secret Key prüfen.";
  if (m.includes("ip") && ["white", "bind", "not allow", "restrict"].some(w => m.includes(w))) return "Deine IP-Adresse ist für diesen Schlüssel nicht freigegeben.";
  if (["api key", "apikey", "api-key", "10003", "invalid"].some(w => m.includes(w))) return "API Key ungültig oder abgelaufen.";
  if (m.includes("timestamp") || m.includes("recv_window")) return "Die Uhrzeit deines PCs weicht ab – bitte Windows-Uhr synchronisieren.";
  if (m.includes("keine verbindung")) return "Keine Verbindung zur Börse – Internet prüfen.";
  return String(msg && msg.message || msg).slice(0, 160);
}

module.exports = { DAY, EXCHANGES, ExchangeError, setFetch, fetchTrades, normalize, rawTime, friendlyError };
