// VantyX – Hintergrund-Dienst: lokaler Server nur für dieses Fenster, Börsen-Sync, Marktdaten, News, Kalender
"use strict";
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const ex = require("./exchanges");

const PORT = 47822;
const INTERVAL = +(process.env.TC_INTERVAL || 120) * 1000;

let DATA, CONFIG, CACHE, OUT, LOGFILE, UI, VERSION = "2.0", TOKEN = crypto.randomBytes(18).toString("base64url");
let httpFetch = (...a) => fetch(...a);
let openExternal = url => console.log("open", url);

function log(msg) {
  const line = new Date().toISOString().replace("T", " ").slice(0, 19) + " " + msg + "\n";
  try {
    if (LOGFILE) {
      try { if (fs.statSync(LOGFILE).size > 2e6) fs.unlinkSync(LOGFILE); } catch {}
      fs.appendFileSync(LOGFILE, line);
    }
  } catch {}
  if (process.env.TC_DEBUG) process.stdout.write(line);
}
const loadJson = (p, d) => { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return d; } };
function saveJson(p, data) { const tmp = p + ".tmp"; fs.writeFileSync(tmp, JSON.stringify(data), "utf8"); fs.renameSync(tmp, p); }
const str = (v, n) => String(v ?? "").slice(0, n);

// ------------------------------------------------------------------ Sync
const SYNC = { status: { state: "idle", msg: "", at: 0 }, timer: null, busy: false };

function writeOut(trades, error = null) {
  const payload = { updated: Date.now(), error, trades };
  const tmp = OUT + ".tmp";
  fs.writeFileSync(tmp, "window.COCKPIT_SYNC=" + JSON.stringify(payload) + ";\n", "utf8");
  fs.renameSync(tmp, OUT);
}

async function runOnce(cfg) {
  const exch = cfg.exchange, hint = (cfg.api_key || "").slice(-4);
  let cache = loadJson(CACHE, {});
  if (cache.exchange !== exch || cache.key_hint !== hint) cache = { exchange: exch, key_hint: hint, raw: {} };
  const raw = cache.raw;
  const vals = Object.values(raw);
  const since = vals.length && cache.backfilled
    ? Math.max(...vals.map(r => ex.rawTime(exch, r))) - 3 * ex.DAY
    : Date.now() - 400 * ex.DAY;
  const got = await ex.fetchTrades(exch, cfg, since);
  const neu = Object.keys(got).filter(k => !(k in raw)).length;
  Object.assign(raw, got);
  cache.backfilled = true;
  saveJson(CACHE, cache);
  const trades = [];
  for (const r of Object.values(raw)) { try { trades.push(ex.normalize(exch, r)); } catch (e) { log(`Datensatz übersprungen: ${e.message}`); } }
  trades.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  writeOut(trades);
  return [neu, trades.length];
}

async function syncLoop() {
  clearTimeout(SYNC.timer);
  const cfg = loadJson(CONFIG, {});
  const E = ex.EXCHANGES[cfg.exchange];
  if (E && E.api && cfg.api_key && cfg.secret_key && !SYNC.busy) {
    SYNC.busy = true;
    try {
      SYNC.status = { state: "sync", msg: "Abgleich läuft…", at: Date.now() / 1000 };
      const [neu, total] = await runOnce(cfg);
      SYNC.status = { state: "ok", msg: `${total} Trades`, at: Date.now() / 1000 };
      log(`Abgleich ok – ${neu} neu, ${total} insgesamt (${cfg.exchange}).`);
    } catch (e) {
      const msg = ex.friendlyError(e);
      SYNC.status = { state: "error", msg, at: Date.now() / 1000 };
      log(`Fehler: ${e.message}`);
      try {
        const old = loadJson(CACHE, {});
        writeOut(old.raw ? Object.values(old.raw).map(r => ex.normalize(old.exchange, r)) : [], msg);
      } catch { try { writeOut([], msg); } catch {} }
    } finally { SYNC.busy = false; }
  }
  SYNC.timer = setTimeout(syncLoop, INTERVAL);
}
const wakeSync = () => setTimeout(syncLoop, 50);

// ------------------------------------------------------------------ Einstellungen
const cleanUrl = v => { let u = str(v, 300).trim(); if (!u) return ""; if (!/^https?:\/\//i.test(u)) u = "https://" + u;
  try { const x = new URL(u); return /^https?:$/.test(x.protocol) && x.hostname.includes(".") ? x.href : ""; } catch { return ""; } };
const exchangeUrl = cfg => { const E = ex.EXCHANGES[cfg.exchange] || {}; return E.custom ? cleanUrl(cfg.custom_url) : (E.trade_url || ""); };
function publicSettings() {
  const cfg = loadJson(CONFIG, {}), exch = cfg.exchange || "", E = ex.EXCHANGES[exch] || {};
  return { version: VERSION, configured: !!(cfg.name && exch), name: cfg.name || "", exchange: exch,
    exchangeName: (E.custom && cfg.custom_name) || E.name || "", tradeUrl: exchangeUrl(cfg), customName: cfg.custom_name || "", customUrl: cfg.custom_url || "", hasKeys: !!(cfg.api_key && cfg.secret_key),
    keyHint: cfg.api_key ? "…" + cfg.api_key.slice(-4) : "",
    hasPass: !!cfg.passphrase,
    exchanges: Object.fromEntries(Object.entries(ex.EXCHANGES).map(([k, v]) => [k, { name: v.name, api: v.api, pass: !!v.pass, keyUrl: v.key_url || "" }])),
    sync: SYNC.status, prefs: cfg.prefs || null };
}

async function testConnection(body) {
  const exch = body.exchange, cfg = loadJson(CONFIG, {});
  const key = str(body.api_key, 200).trim() || (cfg.exchange === exch ? cfg.api_key : "");
  const sec = str(body.secret_key, 200).trim() || (cfg.exchange === exch ? cfg.secret_key : "");
  const pass = str(body.passphrase, 200) || (cfg.exchange === exch ? cfg.passphrase || "" : "");
  if (!ex.EXCHANGES[exch] || !ex.EXCHANGES[exch].api) return { ok: false, error: "Für diese Börse gibt es keine API-Anbindung." };
  if (!key || !sec) return { ok: false, error: "Bitte API Key und Secret Key eingeben." };
  if (ex.EXCHANGES[exch].pass && !pass) return { ok: false, error: "Bitte auch die Passphrase eingeben." };
  try {
    const got = await ex.fetchTrades(exch, { api_key: key, secret_key: sec, passphrase: pass }, Date.now() - 7 * ex.DAY);
    return { ok: true, count: Object.keys(got).length };
  } catch (e) { log(`Verbindungstest fehlgeschlagen: ${e.message}`); return { ok: false, error: ex.friendlyError(e) }; }
}

function saveSettings(body) {
  const cfg = loadJson(CONFIG, {});
  const name = str(body.name, 40).trim(), exch = body.exchange;
  if (!name || !ex.EXCHANGES[exch]) return { ok: false, error: "Name und Börse werden gebraucht." };
  if (exch !== cfg.exchange) { delete cfg.api_key; delete cfg.secret_key; delete cfg.passphrase; }
  Object.assign(cfg, { name, exchange: exch });
  if (ex.EXCHANGES[exch].custom) {
    const cn = str(body.custom_name, 40).trim(), cu = cleanUrl(body.custom_url);
    if (!cn) return { ok: false, error: "Bitte gib den Namen deiner Börse ein." };
    if (body.custom_url && !cu) return { ok: false, error: "Die Adresse der Börse sieht nicht richtig aus (z. B. www.boerse.com)." };
    cfg.custom_name = cn; cfg.custom_url = cu;
  } else { delete cfg.custom_name; delete cfg.custom_url; }
  for (const k of ["api_key", "secret_key"]) { const v = str(body[k], 200).trim(); if (v) cfg[k] = v; }
  { const v = str(body.passphrase, 200); if (v) cfg.passphrase = v; }
  if (!ex.EXCHANGES[exch].api) { delete cfg.api_key; delete cfg.secret_key; delete cfg.passphrase; }
  if (!ex.EXCHANGES[exch].pass) delete cfg.passphrase;
  if (Array.isArray(body.assets)) (cfg.prefs = cfg.prefs || {}).assets = body.assets.slice(0, 40).map(a => str(a, 12));
  saveJson(CONFIG, cfg);
  wakeSync();
  return { ok: true, settings: publicSettings() };
}

function savePrefs(body) {
  const cfg = loadJson(CONFIG, {}), p = cfg.prefs || {};
  if (Array.isArray(body.assets)) p.assets = body.assets.slice(0, 40).map(a => str(a, 12));
  for (const k of ["active", "tf"]) if (typeof body[k] === "string") p[k] = body[k].slice(0, 12);
  if (typeof body.dayLimit === "number" && body.dayLimit >= 1 && body.dayLimit <= 50) p.dayLimit = Math.trunc(body.dayLimit);
  if ("layout" in body && (body.layout === null || Array.isArray(body.layout))) p.layout = body.layout && body.layout.length ? body.layout.slice(0, 60) : null;
  for (const k of ["rail", "notify", "mini"]) if (typeof body[k] === "boolean") p[k] = body[k];
  if (typeof body.dv === "number" && body.dv >= 0 && body.dv < 100) p.dv = Math.trunc(body.dv);
  if (Array.isArray(body.events)) p.events = body.events.slice(0, 200).filter(e => e && typeof e === "object")
    .map(e => Object.fromEntries(["id", "d", "t", "t2", "title"].map(k => [k, str(e[k], 80)])));
  if (body.cal && typeof body.cal === "object") p.cal = { imp: (body.cal.imp || []).slice(0, 5).map(x => str(x, 10)), cur: (body.cal.cur || []).slice(0, 12).map(x => str(x, 4)) };
  if (typeof body.newsTab === "string") p.newsTab = body.newsTab.slice(0, 10);
  if (Array.isArray(body.strategies)) p.strategies = body.strategies.slice(0, 40).filter(x => x && typeof x === "object" && String(x.n || "").trim())
    .map(x => ({ n: str(x.n, 40).trim(), c: /^#[0-9a-f]{6}$/i.test(x.c) ? x.c : "#8B5CF6" }));
  if (Array.isArray(body.pages)) p.pages = body.pages.slice(0, 6).filter(x => x && typeof x === "object").map(x => ({
    id: str(x.id, 20), name: str(x.name, 24),
    items: (Array.isArray(x.items) ? x.items : []).slice(0, 8).filter(it => it && typeof it === "object" && ["S", "M", "L", "XL"].includes(it.s))
      .map(it => ({ id: str(it.id, 20), s: it.s, x: Math.max(0, Math.min(3, Math.trunc(+it.x || 0))), y: Math.max(0, Math.min(1, Math.trunc(+it.y || 0))) }))
  }));
  if (typeof body.tvUrl === "string" && /^https:\/\/([a-z0-9-]+\.)*tradingview\.com\//i.test(body.tvUrl)) p.tvUrl = body.tvUrl.slice(0, 300);
  cfg.prefs = p;
  saveJson(CONFIG, cfg);
  return { ok: true };
}

// ------------------------------------------------------------------ Marktdaten (Yahoo), Kalender, News
async function getText(url, timeout = 12000, accept = "*/*") {
  const r = await httpFetch(url, { headers: { "User-Agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) VantyX/${VERSION}`, Accept: accept }, signal: AbortSignal.timeout(timeout) });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.text();
}

const YAHOO = new Map();
async function yahoo(q) {
  const s = q.get("s") || "", i = q.get("i") || "1d", r = q.get("r") || "1mo";
  if (!/^[A-Za-z0-9=^.\-]{1,15}$/.test(s) || !["1d", "1wk", "1mo"].includes(i) || !["5d", "1mo", "3mo", "6mo", "1y"].includes(r)) return null;
  const key = `${s}|${i}|${r}`, hit = YAHOO.get(key);
  if (hit && Date.now() - hit[0] < 45000) return hit[1];
  const base = process.env.TC_YAHOO_BASE || "https://query1.finance.yahoo.com";
  const data = await getText(`${base}/v8/finance/chart/${encodeURIComponent(s)}?interval=${i}&range=${r}&includePrePost=false`, 15000, "application/json");
  YAHOO.set(key, [Date.now(), data]);
  return data;
}

const CAL_URLS = process.env.TC_CAL_URLS ? JSON.parse(process.env.TC_CAL_URLS) :
  ["https://nfs.faireconomy.media/ff_calendar_thisweek.json", "https://nfs.faireconomy.media/ff_calendar_nextweek.json"];
const NEWS_FEEDS = process.env.TC_NEWS_FEEDS ? JSON.parse(process.env.TC_NEWS_FEEDS) : [
  ["BTC-ECHO", "krypto", "https://www.btc-echo.de/feed/"],
  ["CoinDesk", "krypto", "https://www.coindesk.com/arc/outboundfeeds/rss/"],
  ["Cointelegraph", "krypto", "https://cointelegraph.com/rss"],
  ["finanzen.net", "markt", "https://www.finanzen.net/rss/news"],
  ["MarketWatch", "markt", "https://feeds.content.dowjones.io/public/rss/mw_topstories"]];
const CAL = { t: 0, data: null, p: null }, NEWS = { t: 0, data: null, p: null }, NEWS_LINKS = new Set();

function calendar() {
  if (CAL.data && Date.now() - CAL.t < 1800e3) return Promise.resolve(CAL.data);
  if (CAL.p) return CAL.p;
  CAL.p = (async () => {
    const events = []; let err = false;
    const res = await Promise.allSettled(CAL_URLS.map(u => getText(u)));
    res.forEach((r, i) => {
      if (r.status !== "fulfilled") { if (i === 0) { err = true; log(`Kalender-Fehler: ${r.reason?.message}`); } return; }
      try { for (const e of JSON.parse(r.value)) if (e && e.date) events.push(Object.fromEntries(["title", "country", "date", "impact", "forecast", "previous"].map(k => [k, str(e[k] || "", 120)]))); }
      catch (e) { if (i === 0) err = true; }
    });
    const data = { events, error: err && !events.length ? "Wirtschaftskalender gerade nicht erreichbar" : null };
    if (events.length || !CAL.data) { CAL.data = data; CAL.t = events.length ? Date.now() : Date.now() - 1500e3; }
    return CAL.data;
  })().finally(() => { CAL.p = null; });
  return CAL.p;
}

const ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
const decode = s => s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => e[0] === "#" ? String.fromCodePoint(e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e.toLowerCase()] ?? m));
function tag(item, name) {
  const m = item.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, "i"));
  if (!m) return "";
  let v = m[1].trim();
  const cd = v.match(/^<!\[CDATA\[([\s\S]*?)\]\]>$/); v = cd ? cd[1] : decode(v);
  return decode(v.replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
}
async function feed([src, cat, url]) {
  const xml = await getText(url, 12000, "application/rss+xml, application/xml, text/xml");
  const out = [];
  for (const m of xml.matchAll(/<item[\s>][\s\S]*?<\/item>/gi)) {
    const it = m[0], link = tag(it, "link");
    if (!/^https?:\/\//.test(link)) continue;
    const ts = Date.parse(tag(it, "pubDate")) || 0;
    out.push({ title: tag(it, "title").slice(0, 220), link: link.slice(0, 500), src, cat, ts, desc: tag(it, "description").slice(0, 260) });
    if (out.length >= 25) break;
  }
  return out;
}
function news() {
  if (NEWS.data && Date.now() - NEWS.t < 300e3) return Promise.resolve(NEWS.data);
  if (NEWS.p) return NEWS.p;
  NEWS.p = (async () => {
    let items = []; const failed = [];
    const res = await Promise.allSettled(NEWS_FEEDS.map(feed));
    res.forEach((r, i) => { if (r.status === "fulfilled") items.push(...r.value); else { failed.push(NEWS_FEEDS[i][0]); log(`News-Fehler ${NEWS_FEEDS[i][0]}: ${r.reason?.message}`); } });
    items.sort((a, b) => b.ts - a.ts); items = items.slice(0, 120);
    items.forEach(x => NEWS_LINKS.add(x.link));
    const data = { items, failed };
    if (items.length || !NEWS.data) { NEWS.data = data; NEWS.t = items.length ? Date.now() : Date.now() - 240e3; }
    return NEWS.data;
  })().finally(() => { NEWS.p = null; });
  return NEWS.p;
}

// ------------------------------------------------------------------ HTTP-Server (nur 127.0.0.1, nur mit Token)
const PUBLIC = { "/vantyx.html": "text/html; charset=utf-8", "/vantyx-256.png": "image/png", "/vantyx-192.png": "image/png",
  "/vantyx-512.png": "image/png", "/vantyx.webmanifest": "application/manifest+json", "/vantyx.ico": "image/x-icon", "/nyxor-x3.ico": "image/x-icon", "/vela.js": "text/javascript; charset=utf-8" };

function send(res, code, body, type = "application/json; charset=utf-8") {
  const b = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === "string" ? body : JSON.stringify(body));
  res.writeHead(code, { "Content-Type": type, "Content-Length": b.length, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
  res.end(b);
}
const safeEq = (a, b) => { const x = Buffer.from(String(a || "")), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

function authorized(req) {
  const o = req.headers.origin;
  if (o && o !== `http://127.0.0.1:${PORT}`) return false;
  return safeEq(req.headers["x-cockpit-token"], TOKEN);
}

async function handle(req, res) {
  const u = new URL(req.url, `http://127.0.0.1:${PORT}`), p = u.pathname;
  if (req.headers.host && req.headers.host !== `127.0.0.1:${PORT}`) return send(res, 403, { error: "forbidden" });   // Schutz vor DNS-Rebinding
  if (req.method === "POST") {
    if (!authorized(req)) return send(res, 403, { error: "forbidden" });
    let body = "";
    for await (const c of req) { body += c; if (body.length > 20000) return send(res, 413, { ok: false }); }
    try { body = JSON.parse(body || "{}"); } catch { return send(res, 400, { ok: false, error: "Ungültige Anfrage" }); }
    if (p === "/api/settings") return send(res, 200, saveSettings(body));
    if (p === "/api/prefs") return send(res, 200, savePrefs(body));
    if (p === "/api/test") return send(res, 200, await testConnection(body));
    if (p === "/api/sync-now") { wakeSync(); return send(res, 200, { ok: true }); }
    if (p === "/api/open") {
      const url = String(body.url || "");
      if (NEWS_LINKS.has(url)) { openExternal(url); return send(res, 200, { ok: true }); }
      return send(res, 400, { ok: false });
    }
    return send(res, 404, { error: "not found" });
  }
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, { error: "method" });
  if (p === "/") { res.writeHead(302, { Location: `/vantyx.html?t=${TOKEN}` }); return res.end(); }
  if (p === "/cockpit-data.js") {
    if (!safeEq(u.searchParams.get("t"), TOKEN)) return send(res, 403, "");
    try { return send(res, 200, fs.readFileSync(OUT), "text/javascript; charset=utf-8"); } catch { return send(res, 404, ""); }
  }
  if (p.startsWith("/go/")) {
    const cfg = loadJson(CONFIG, {});
    const links = { exchange: exchangeUrl(cfg), tradingview: "https://www.tradingview.com/chart/",
      keys: (ex.EXCHANGES[u.searchParams.get("ex") || u.search.split("=").pop()] || {}).key_url };
    const url = links[p.slice(4)];
    if (url) openExternal(url);
    res.writeHead(204); return res.end();
  }
  if (p === "/api/settings" || p === "/api/calendar" || p === "/api/news" || p === "/api/yahoo") {
    if (!authorized(req)) return send(res, 403, { error: "forbidden" });
    if (p === "/api/settings") return send(res, 200, publicSettings());
    if (p === "/api/calendar") return send(res, 200, await calendar());
    if (p === "/api/news") return send(res, 200, await news());
    try {
      const d = await yahoo(u.searchParams);
      return d === null ? send(res, 400, { error: "bad" }) : send(res, 200, d);
    } catch (e) { log(`Marktdaten-Fehler: ${e.message}`); return send(res, 502, { error: "Marktdaten nicht erreichbar" }); }
  }
  const file = p === "/favicon.ico" ? "/nyxor-x3.ico" : p;
  if (PUBLIC[file]) {
    try { return send(res, 200, fs.readFileSync(path.join(UI, file)), PUBLIC[file]); } catch { return send(res, 404, ""); }
  }
  return send(res, 404, "Not found", "text/plain");
}

function start(opts) {
  DATA = opts.dataDir; UI = opts.uiDir; VERSION = opts.version || VERSION;
  if (opts.fetch) { httpFetch = opts.fetch; ex.setFetch(opts.fetch); }
  if (opts.openExternal) openExternal = opts.openExternal;
  if (process.env.TC_TOKEN) TOKEN = process.env.TC_TOKEN;
  fs.mkdirSync(DATA, { recursive: true });
  CONFIG = path.join(DATA, "config.json"); CACHE = path.join(DATA, "cache.json"); OUT = path.join(DATA, "cockpit-data.js"); LOGFILE = path.join(DATA, "vantyx.log");
  return new Promise((resolve, reject) => {
    const srv = http.createServer((req, res) => handle(req, res).catch(e => { log(`Serverfehler: ${e.stack || e}`); try { send(res, 500, { error: "intern" }); } catch {} }));
    srv.once("error", reject);
    srv.listen(PORT, "127.0.0.1", () => {
      log(`Nyxor ${VERSION} gestartet`);
      SYNC.timer = setTimeout(syncLoop, 300);
      resolve({ url: `http://127.0.0.1:${PORT}/vantyx.html?t=${TOKEN}`, server: srv });
    });
  });
}

module.exports = { start, log, loadJson, calendar, PORT, get token() { return TOKEN; }, get configPath() { return CONFIG; } };
