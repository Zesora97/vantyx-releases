﻿#  Nyxor (ehemals VantyX) – Installation (Windows)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Version = '2.13.1 Beta'
$Src     = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppSrc  = Join-Path $Src 'VantyX'
$UiSrc   = Join-Path $AppSrc 'resources\app\ui'
$Dest    = Join-Path $env:LOCALAPPDATA 'Programs\VantyX'
$OldDest = Join-Path $env:LOCALAPPDATA 'Programs\Trading Cockpit'

# ---------------------------------------------------------------- Fenster
$bg   = [System.Drawing.Color]::FromArgb(11, 11, 15)
$fg   = [System.Drawing.Color]::White
$sub  = [System.Drawing.Color]::FromArgb(154, 154, 171)
$blue = [System.Drawing.Color]::FromArgb(56, 150, 230)

$form = New-Object System.Windows.Forms.Form
$form.Text = "Nyxor $Version – Installation"
$form.ClientSize = New-Object System.Drawing.Size(560, 400)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.BackColor = $bg
$form.ForeColor = $fg
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
try { $form.Icon = New-Object System.Drawing.Icon (Join-Path $UiSrc 'nyxor-x3.ico') } catch {}

$pic = New-Object System.Windows.Forms.PictureBox
$pic.Location = New-Object System.Drawing.Point(32, 30)
$pic.Size = New-Object System.Drawing.Size(76, 76)
$pic.SizeMode = 'Zoom'
try { $pic.Image = [System.Drawing.Image]::FromFile((Join-Path $UiSrc 'vantyx-256.png')) } catch {}
$form.Controls.Add($pic)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'NYXOR'
$title.Font = New-Object System.Drawing.Font('Segoe UI', 22, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(128, 34)
$title.AutoSize = $true
$form.Controls.Add($title)

$ver = New-Object System.Windows.Forms.Label
$ver.Text = "TRADE WITH CLARITY  ·  Version $Version"
$ver.ForeColor = [System.Drawing.Color]::FromArgb(167, 139, 250)
$ver.ForeColor = $sub
$ver.Location = New-Object System.Drawing.Point(131, 78)
$ver.AutoSize = $true
$form.Controls.Add($ver)

$info = New-Object System.Windows.Forms.Label
$info.Text = "Dein Trading-Cockpit für Journal, Statistik, Marktdaten und TradingView – jetzt als eigenständiges Programm.`r`n`r`nWährend der Installation wird der Programmkern (ca. 140 MB) geladen – bitte mit dem Internet verbunden bleiben. Einstellungen, Trades und Notizen einer älteren Version werden übernommen."
$info.ForeColor = $sub
$info.Location = New-Object System.Drawing.Point(32, 128)
$info.Size = New-Object System.Drawing.Size(496, 90)
$form.Controls.Add($info)

$cbDesk = New-Object System.Windows.Forms.CheckBox
$cbDesk.Text = 'Verknüpfung auf dem Desktop anlegen'
$cbDesk.Checked = $true
$cbDesk.Location = New-Object System.Drawing.Point(32, 224)
$cbDesk.AutoSize = $true
$form.Controls.Add($cbDesk)

$cbStart = New-Object System.Windows.Forms.CheckBox
$cbStart.Text = 'Nyxor nach der Installation starten'
$cbStart.Checked = $true
$cbStart.Location = New-Object System.Drawing.Point(32, 252)
$cbStart.AutoSize = $true
$form.Controls.Add($cbStart)

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Location = New-Object System.Drawing.Point(32, 296)
$bar.Size = New-Object System.Drawing.Size(496, 8)
$bar.Style = 'Continuous'
$bar.Visible = $false
$form.Controls.Add($bar)

$status = New-Object System.Windows.Forms.Label
$status.Text = ''
$status.ForeColor = $sub
$status.Location = New-Object System.Drawing.Point(32, 310)
$status.Size = New-Object System.Drawing.Size(496, 24)
$form.Controls.Add($status)

$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Text = 'Abbrechen'
$btnCancel.Location = New-Object System.Drawing.Point(300, 346)
$btnCancel.Size = New-Object System.Drawing.Size(110, 36)
$btnCancel.FlatStyle = 'Flat'
$btnCancel.BackColor = [System.Drawing.Color]::FromArgb(28, 28, 38)
$btnCancel.Add_Click({ $form.Close() })
$form.Controls.Add($btnCancel)

$btnOk = New-Object System.Windows.Forms.Button
$btnOk.Text = 'Installieren'
$btnOk.Location = New-Object System.Drawing.Point(418, 346)
$btnOk.Size = New-Object System.Drawing.Size(110, 36)
$btnOk.FlatStyle = 'Flat'
$btnOk.BackColor = $blue
$btnOk.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($btnOk)
$form.AcceptButton = $btnOk

function Step($text, $pct) {
    $status.Text = $text
    $bar.Value = $pct
    [System.Windows.Forms.Application]::DoEvents()
}

$script:done = $false
$script:exe = $null

$btnOk.Add_Click({
    if ($script:done) { $form.Close(); return }
    $btnOk.Enabled = $false; $btnCancel.Enabled = $false; $cbDesk.Enabled = $false; $cbStart.Enabled = $false
    $bar.Visible = $true
    try {
        Step 'Beende laufende Nyxor-Fenster …' 10
        Get-Process -Name 'VantyX' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*cockpit_app.pyw*' -or $_.CommandLine -like '*vantyx.pyw*' -or $_.CommandLine -like '*VantyX*app-profil*' -or $_.CommandLine -like '*Trading Cockpit*app-profil*' } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 1500

        Step 'Entferne Vorgängerversionen …' 18
        foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
            Remove-Item -Path (Join-Path $dir 'Trading Cockpit.lnk') -Force -ErrorAction SilentlyContinue
        }
        Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TradingCockpit' -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $OldDest) { Remove-Item -Path $OldDest -Recurse -Force -ErrorAction SilentlyContinue }

        $Work = $null
        $updateOnly = $false
        $instExe = Join-Path $Dest 'VantyX.exe'
        if (-not (Test-Path (Join-Path $AppSrc 'VantyX.exe')) -and (Test-Path $instExe)) {
            Step 'Prüfe vorhandene Installation …' 20
            try {
                $want = (Get-Content -Raw -LiteralPath (Join-Path $Src 'vantyx-exe.patch.json') | ConvertFrom-Json).dstSha256
                if ((Get-FileHash -Algorithm SHA256 -LiteralPath $instExe).Hash.ToLowerInvariant() -eq $want) { $updateOnly = $true }
            } catch {}
        }
        if ($updateOnly) {
            Step 'Aktualisiere Nyxor …' 60
            $rc = Start-Process -FilePath 'robocopy.exe' -ArgumentList @("`"$(Join-Path $Src 'app')`"", "`"$(Join-Path $Dest 'resources\app')`"", '/MIR', '/R:3', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP') -WindowStyle Hidden -PassThru
            while (-not $rc.HasExited) { Start-Sleep -Milliseconds 200; [System.Windows.Forms.Application]::DoEvents() }
            if ($rc.ExitCode -ge 8) { throw "Die Programmdateien konnten nicht aktualisiert werden (Fehler $($rc.ExitCode)).`r`nIst Nyxor noch geöffnet? Bitte schließen und erneut versuchen." }
            Copy-Item -Path (Join-Path $Src 'uninstall.ps1') -Destination $Dest -Force
        }
        elseif (-not (Test-Path (Join-Path $AppSrc 'VantyX.exe'))) {
            if (-not (Test-Path (Join-Path $Src 'app\main.js')) -or -not (Test-Path (Join-Path $Src 'vantyx-exe.patch.json'))) {
                throw "Die Setup-Dateien sind unvollständig.`r`nBitte die ZIP-Datei komplett entpacken und Setup.cmd aus dem entpackten Ordner starten."
            }
            $Work = Join-Path $env:TEMP 'VantyX-Setup'
            New-Item -ItemType Directory -Force -Path $Work | Out-Null
            Remove-Item -LiteralPath (Join-Path $Work 'stage.txt') -Force -ErrorAction SilentlyContinue
            Step 'Bereite Download vor …' 8
            $job = Start-Job -FilePath (Join-Path $Src 'vantyx-build.ps1') -ArgumentList $Src, $Work
            $part = Join-Path $Work 'electron-v43.2.0-win32-x64.zip.part'
            while ($job.State -eq 'Running' -or $job.State -eq 'NotStarted') {
                Start-Sleep -Milliseconds 300
                $stage = ''
                try { $stage = (Get-Content -LiteralPath (Join-Path $Work 'stage.txt') -Raw -ErrorAction Stop).Trim() } catch {}
                if ($stage -eq 'download') {
                    $mb = 0
                    try { $mb = [math]::Round((Get-Item -LiteralPath $part -ErrorAction Stop).Length / 1MB) } catch {}
                    Step "Lade Programmkern von GitHub … $mb von 138 MB" ([math]::Min(55, 8 + [int]($mb / 138 * 47)))
                }
                elseif ($stage -eq 'extract') { Step 'Entpacke Programmkern …' 58 }
                elseif ($stage -eq 'build') { Step 'Baue Nyxor …' 63 }
                else { Step 'Bereite Download vor …' 8 }
            }
            if ($job.State -ne 'Completed') {
                $msg = $job.ChildJobs[0].JobStateInfo.Reason.Message
                if (-not $msg) { $msg = "$($job.ChildJobs[0].Error | Select-Object -First 1)" }
                Remove-Job $job -Force
                throw "Der Programmkern konnte nicht erstellt werden.`r`n$msg"
            }
            Remove-Job $job -Force
            $AppSrc = Join-Path $Work 'VantyX'
        }

        if (-not $updateOnly) {
        Step 'Kopiere Programmdateien …' 66
        if (-not (Test-Path (Join-Path $AppSrc 'VantyX.exe'))) { throw "Die Programmdateien fehlen.`r`nBitte die ZIP-Datei komplett entpacken und Setup.cmd aus dem entpackten Ordner starten." }
        New-Item -ItemType Directory -Force -Path $Dest | Out-Null
        $rc = Start-Process -FilePath 'robocopy.exe' -ArgumentList @("`"$AppSrc`"", "`"$Dest`"", '/MIR', '/R:3', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP') -WindowStyle Hidden -PassThru
        $pct = 66
        while (-not $rc.HasExited) { Start-Sleep -Milliseconds 250; if ($pct -lt 76) { $pct++ }; Step 'Kopiere Programmdateien …' $pct }
        if ($rc.ExitCode -ge 8) { throw "Die Programmdateien konnten nicht kopiert werden (Fehler $($rc.ExitCode)).`r`nIst Nyxor noch geöffnet? Bitte schließen und erneut versuchen." }
        Copy-Item -Path (Join-Path $Src 'uninstall.ps1') -Destination $Dest -Force
        Step 'Gebe Programmdateien frei …' 78
        }
        Get-ChildItem -Path $Dest -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

        Step 'Lege Verknüpfungen an …' 82
        $script:exe = Join-Path $Dest 'VantyX.exe'
        $ico = Join-Path $Dest 'resources\app\ui\nyxor-x3.ico'
        $shell = New-Object -ComObject WScript.Shell
        $targets = @([Environment]::GetFolderPath('Programs'))
        if ($cbDesk.Checked) { $targets += [Environment]::GetFolderPath('Desktop') }
        foreach ($dir in $targets) {
            Remove-Item -LiteralPath (Join-Path $dir 'VantyX.lnk') -Force -ErrorAction SilentlyContinue
            $lnk = $shell.CreateShortcut((Join-Path $dir 'Nyxor.lnk'))
            $lnk.TargetPath = $script:exe
            $lnk.Arguments = ''
            $lnk.WorkingDirectory = $Dest
            $lnk.IconLocation = "$ico,0"
            $lnk.Description = 'Nyxor – Trade with clarity'
            $lnk.Save()
        }

        Step 'Registriere Programm …' 90
        $reg = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\VantyX'
        New-Item -Path $reg -Force | Out-Null
        $un = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $Dest 'uninstall.ps1') + '"'
        $vals = @{ DisplayName = 'Nyxor'; DisplayVersion = $Version; Publisher = 'Nyxor';
                   DisplayIcon = $script:exe; InstallLocation = $Dest; UninstallString = $un }
        foreach ($k in $vals.Keys) { Set-ItemProperty -Path $reg -Name $k -Value $vals[$k] }
        Set-ItemProperty -Path $reg -Name NoModify -Value 1 -Type DWord
        Set-ItemProperty -Path $reg -Name NoRepair -Value 1 -Type DWord
        Set-ItemProperty -Path $reg -Name EstimatedSize -Value 330000 -Type DWord

        if ($Work) { Remove-Item -LiteralPath $Work -Recurse -Force -ErrorAction SilentlyContinue }
        Step 'Fertig! Nyxor ist installiert.' 100
        $script:done = $true
        $btnOk.Text = 'Fertig'
        $btnOk.Enabled = $true
        if ($cbStart.Checked) {
            # über den Explorer starten, damit VantyX nicht am Setup-Prozess (PowerShell) hängt
            Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $script:exe + '"')
            $script:closeTimer = New-Object System.Windows.Forms.Timer
            $script:closeTimer.Interval = 1800
            $script:closeTimer.Add_Tick({ param($sender, $e) try { $sender.Stop(); $script:form.Close() } catch {} })
            $script:closeTimer.Start()
        }
    } catch {
        $status.Text = 'Installation fehlgeschlagen.'
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Nyxor', 'OK', 'Error') | Out-Null
        $btnCancel.Enabled = $true; $btnOk.Enabled = $true; $btnOk.Text = 'Erneut versuchen'
        $cbDesk.Enabled = $true; $cbStart.Enabled = $true
    }
})

[void]$form.ShowDialog()
