﻿#  VantyX – Programmkern bauen (wird vom Setup im Hintergrund ausgeführt)
#  Lädt Electron (offizielle Version von GitHub), prüft die Prüfsumme und erzeugt daraus VantyX.exe.
param(
    [Parameter(Mandatory = $true)][string]$Src,
    [Parameter(Mandatory = $true)][string]$Work
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$Ver    = '43.2.0'
$Url    = "https://github.com/electron/electron/releases/download/v$Ver/electron-v$Ver-win32-x64.zip"
$ZipSha = 'eba5f5088af40ecb364fe258809c79a5234c6ece5a75c64722772eba01b02786'

function Stage([string]$t) { Set-Content -LiteralPath (Join-Path $Work 'stage.txt') -Value $t -Encoding UTF8 }
function Sha([string]$f) { (Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToLowerInvariant() }
function P([string[]]$parts) { $r = $parts[0]; foreach ($x in $parts[1..($parts.Count - 1)]) { $r = Join-Path $r $x }; $r }

New-Item -ItemType Directory -Force -Path $Work | Out-Null

# 1) Electron laden (oder vorhandenen Download wiederverwenden)
$zip = Join-Path $Work "electron-v$Ver-win32-x64.zip"
if (-not (Test-Path -LiteralPath $zip) -or (Sha $zip) -ne $ZipSha) {
    Stage 'download'
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
    $tmp = "$zip.part"
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add('User-Agent', 'VantyX-Setup')
    try { $wc.DownloadFile($Url, $tmp) }
    catch { throw "Download fehlgeschlagen – bitte Internetverbindung prüfen und Setup erneut starten.`r`n($($_.Exception.Message))" }
    finally { $wc.Dispose() }
    if ((Sha $tmp) -ne $ZipSha) {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        throw 'Der Download ist beschädigt (Prüfsumme stimmt nicht). Bitte Setup erneut starten.'
    }
    Move-Item -LiteralPath $tmp -Destination $zip -Force
}

# 2) Entpacken
Stage 'extract'
$out = Join-Path $Work 'VantyX'
if (Test-Path -LiteralPath $out) { Remove-Item -LiteralPath $out -Recurse -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::ExtractToDirectory($zip, $out)

# 3) VantyX daraus bauen
Stage 'build'
Remove-Item -LiteralPath (P @($out, 'resources', 'default_app.asar')) -Force -ErrorAction SilentlyContinue
Get-ChildItem -LiteralPath (Join-Path $out 'locales') -Filter '*.pak' |
    Where-Object { $_.Name -notin @('de.pak', 'en-US.pak') } | Remove-Item -Force
Copy-Item -LiteralPath (Join-Path $Src 'app') -Destination (P @($out, 'resources', 'app')) -Recurse -Force

$p = Get-Content -Raw -LiteralPath (Join-Path $Src 'vantyx-exe.patch.json') | ConvertFrom-Json
$exeSrc = Join-Path $out 'electron.exe'
$exe = Join-Path $out 'VantyX.exe'
if ((Get-Item -LiteralPath $exeSrc).Length -ne [long]$p.srcSize -or (Sha $exeSrc) -ne $p.srcSha256) {
    throw 'Unerwartete Electron-Datei – bitte Setup erneut starten.'
}
Move-Item -LiteralPath $exeSrc -Destination $exe -Force
$fs = [IO.File]::Open($exe, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite)
try {
    $fs.SetLength([long]$p.dstSize)
    foreach ($c in $p.chunks) {
        $d = [Convert]::FromBase64String($c.d)
        $fs.Position = [long]$c.o
        $fs.Write($d, 0, $d.Length)
    }
} finally { $fs.Close() }
if ((Sha $exe) -ne $p.dstSha256) { throw 'VantyX.exe konnte nicht korrekt erstellt werden – bitte Setup erneut starten.' }

Stage 'done'
Write-Output $out
